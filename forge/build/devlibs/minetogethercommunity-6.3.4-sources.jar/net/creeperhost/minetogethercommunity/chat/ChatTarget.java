package net.creeperhost.minetogethercommunity.chat;

/**
 * Created by covers1624 on 20/7/22.
 */
public enum ChatTarget {
    VANILLA,
    PUBLIC,
    GROUP
}

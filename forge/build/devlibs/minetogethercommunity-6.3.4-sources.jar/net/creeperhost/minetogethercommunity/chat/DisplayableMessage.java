package net.creeperhost.minetogethercommunity.chat;

import net.creeperhost.minetogether.lib.chat.message.Message;
import net.creeperhost.minetogethercommunity.util.MessageFormatter;
import net.minecraft.client.GuiMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ComponentRenderUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by covers1624 on 12/10/22.
 */
public abstract class DisplayableMessage<M> {

    private final Minecraft mc = Minecraft.getInstance();
    private final Message message;
    private final Object listener;
    private final List<M> trimmedLines = new LinkedList<>();
    @Nullable
    private GuiMessage builtMessage;
    private boolean dirty;

    protected DisplayableMessage(Message message) {
        this.message = message;
        listener = message.addListener(this, (i, e) -> {
            i.dirty = true;
            i.onModified();
        });
    }

    public void onDead() {
        message.removeListener(listener);
    }

    public void display() {
        format();
        insertAt(0);
    }

    public void format() {
        int addTime = builtMessage != null ? builtMessage.addedTime() : mc.gui.getGuiTicks();
        builtMessage = new GuiMessage(addTime, MessageFormatter.formatMessage(message), null, null);
        trimmedLines.clear();

        int maxLen = Mth.floor(getChatWidth());
        List<FormattedCharSequence> lines = ComponentRenderUtils.wrapComponents(builtMessage.content(), maxLen, mc.font);
        for (FormattedCharSequence line : lines) {
            trimmedLines.add(createMessage(addTime, line));
        }

        // Why would we ever build no lines?
        assert !trimmedLines.isEmpty();
    }

    public List<M> getTrimmedLines() {
        return trimmedLines;
    }

    @Nullable
    public Component getBuiltMessage() {
        return builtMessage.content();
    }

    public Message getMessage() {
        return message;
    }

    public void reformat() {
        if (!dirty) return;
        dirty = false;
        // Message has not been displayed yet.
        if (builtMessage == null) return;

        // If we are running in forward mode (oldest at index 0), we want message in index 0.
        // If we are running in backwards mode (oldest at index size - 1), we want message in index size - 1.
        int trimmedIdx = getMessageIndex(isForward() ? trimmedLines.get(0) : trimmedLines.get(trimmedLines.size() - 1));
        //TODO figure out why this sometimes breaks.
        // Annoyingly, this is one of those illusive issues that run away and hide as soon as you try to troubleshoot them.
        if (trimmedIdx == -1) {
            return;
        }

        clearMessages();

        format();
        insertAt(trimmedIdx);
    }

    private void insertAt(int trimmedIdx) {
        for (M trimmedLine : trimmedLines) {
            addMessage(trimmedIdx, trimmedLine);
        }
    }

    protected abstract void onModified();

    protected abstract boolean isForward();

    protected abstract M createMessage(int addTime, FormattedCharSequence message);

    protected abstract int getMessageIndex(M message);

    protected abstract void clearMessages();

    protected abstract void addMessage(int index, M message);

    protected abstract double getChatWidth();
}

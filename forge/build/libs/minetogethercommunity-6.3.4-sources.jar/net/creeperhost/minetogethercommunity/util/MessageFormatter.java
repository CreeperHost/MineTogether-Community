package net.creeperhost.minetogethercommunity.util;

import net.creeperhost.minetogethercommunity.chat.MineTogetherChat;
import net.creeperhost.minetogether.lib.chat.message.Message;
import net.creeperhost.minetogether.lib.chat.message.MessageComponent;
import net.creeperhost.minetogether.lib.chat.message.ProfileMessageComponent;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.*;
import net.minecraft.network.chat.ClickEvent.Action;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static net.minecraft.ChatFormatting.RED;
import static net.minecraft.ChatFormatting.RESET;

/**
 * Created by covers1624 on 11/8/22.
 */
public class MessageFormatter {

    public static final HoverEvent.Action<Component> SHOW_URL_PREVIEW = new HoverEvent.Action<>("show_url_preview", true, Component.Serializer::m_130691_, Component.Serializer::m_130716_, component -> component);
    public static final String CLICK_NAME = "CE:CLICK_NAME";

    private static final Pattern URL_PATTERN = Pattern.compile(
            //         schema                          ipv4            OR        namespace                 port     path         ends
            //   |-----------------|        |-------------------------|  |-------------------------|    |---------| |--|   |---------------|
            "((?:[a-z0-9]{2,}:\\/\\/)?(?:(?:[0-9]{1,3}\\.){3}[0-9]{1,3}|(?:[-\\w_]{1,}\\.[a-z]{2,}?))(?::[0-9]{1,5})?.*?(?=[!\"\u00A7 \n]|$))", Pattern.CASE_INSENSITIVE);

    public static Component formatMessage(Message message) {
        ChatFormatting mc = getMessageColour(message);
        ChatFormatting ac = getArrowColour(message);
        ChatFormatting uc = getUserColour(message);

        // TODO obfuscate banned user messages.
        String sender = ac + "<" + uc + message.senderName + ac + ">" + RESET;

        return Component.m_237113_(sender).m_130938_(e -> e.m_131142_(new ClickEvent(Action.SUGGEST_COMMAND, CLICK_NAME)))
                .m_130946_(" ")
                .m_7220_(formatMessage(message.getMessage(), mc));
    }

    private static Component formatMessage(MessageComponent comp, ChatFormatting messageColour) {
        MutableComponent component = Component.m_237113_("").m_130940_(messageColour);
        for (MessageComponent c : comp.iterate()) {
            if (c instanceof ProfileMessageComponent profileComp && profileComp.profile == MineTogetherChat.getOurProfile()) {
                // Mentions get red
                component.m_7220_(Component.m_237113_(c.getMessage()).m_130940_(RED));
            } else {
                component.m_7220_(sugarLinkWithPreview(c.getMessage(), true, messageColour));
            }
        }
        return component;
    }

    private static ChatFormatting getMessageColour(Message message) {
        // If sender is null, it's a System/Moderator message, default to White.
        if (message.sender != null) {
            // Banned users are dark gray.
            if (message.sender.isBanned()) return ChatFormatting.DARK_GRAY;
            // Gray for our own messages.
            if (message.sender == MineTogetherChat.getOurProfile()) return ChatFormatting.GRAY;
        }
        return ChatFormatting.WHITE;
    }

    public static ChatFormatting getArrowColour(Message message) {
        if (message.sender != null) {
            // Premium users get Green.
            if (message.sender.isPremium()) return ChatFormatting.GREEN;
            // Gray for our own messages if we aren't premium.
            if (message.sender == MineTogetherChat.getOurProfile()) return ChatFormatting.GRAY;
        }
        // Otherwise White for non-premium users and System/Moderator messages.
        return ChatFormatting.WHITE;
    }

    private static ChatFormatting getUserColour(Message message) {
        // System/Moderator messages get Aqua.
        if (message.sender == null) return ChatFormatting.AQUA;

        boolean isOnSamePack = MineTogetherChat.getOurProfile().isOnSamePack(message.sender);

        // Friends get yellow, gold if they are on the same modpack.
        if (message.sender.isFriend()) return isOnSamePack ? ChatFormatting.GOLD : ChatFormatting.YELLOW;
        // Our own name is Gray.
        if (message.sender == MineTogetherChat.getOurProfile()) return ChatFormatting.GRAY;
        // People on the same pack get dark purple.
        if (isOnSamePack) return ChatFormatting.DARK_PURPLE;

        // Otherwise, White.
        return ChatFormatting.WHITE;
    }

    //Copied from forge
    private static Component sugarLinkWithPreview(String string, boolean allowMissingHeader, ChatFormatting messageColour) {
        // Includes ipv4 and domain pattern
        // Matches an ip (xx.xxx.xx.xxx) or a domain (something.com) with or
        // without a protocol or path.
        MutableComponent ichat = null;
        Matcher matcher = URL_PATTERN.matcher(string);
        int lastEnd = 0;

        // Find all urls
        while (matcher.find()) {
            int start = matcher.start();
            int end = matcher.end();

            // Append the previous left overs.
            String part = string.substring(lastEnd, start);
            if (part.length() > 0) {
                if (ichat == null) {
                    ichat = Component.m_237113_(part).m_130940_(messageColour);
                } else {
                    ichat.m_130946_(part);
                }
            }
            lastEnd = end;
            String url = string.substring(start, end);
            MutableComponent link = Component.m_237113_(url);

            try {
                // Add schema so client doesn't crash.
                if ((new URI(url)).getScheme() == null) {
                    if (!allowMissingHeader) {
                        if (ichat == null) {
                            ichat = Component.m_237113_(url);
                        } else {
                            ichat.m_130946_(url);
                        }
                        continue;
                    }
                    url = "http://" + url;
                }
            } catch (URISyntaxException e) {
                // Bad syntax bail out!
                if (ichat == null) {
                    ichat = Component.m_237113_(url);
                } else {
                    ichat.m_130946_(url);
                }
                continue;
            }

            // Set the click event and append the link.
            ClickEvent click = new ClickEvent(ClickEvent.Action.OPEN_URL, url);
            HoverEvent hoverEvent = new HoverEvent(SHOW_URL_PREVIEW, Component.m_237113_(url));
            link.m_6270_(link.m_7383_().m_131142_(click).m_131144_(hoverEvent).m_131162_(true).m_131148_(TextColor.m_131270_(ChatFormatting.BLUE)));
            if (ichat == null) {
                ichat = Component.m_237113_("");
            }
            ichat.m_7220_(link);
        }

        // Append the rest of the message.
        String end = string.substring(lastEnd);
        if (ichat == null) {
            ichat = Component.m_237113_(end).m_130940_(messageColour);
        } else if (end.length() > 0) {
            ichat.m_7220_(Component.m_237113_(string.substring(lastEnd)).m_130940_(messageColour));
        }
        return ichat;
    }
}

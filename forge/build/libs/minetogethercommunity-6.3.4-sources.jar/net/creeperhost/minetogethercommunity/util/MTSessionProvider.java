package net.creeperhost.minetogethercommunity.util;

import dev.architectury.injectables.targets.ArchitecturyTarget;
import dev.architectury.platform.Platform;
import net.creeperhost.minetogethercommunity.MineTogetherPlatform;
import net.creeperhost.minetogether.lib.MineTogetherLib;
import net.creeperhost.minetogether.session.MojangUtils;
import net.creeperhost.minetogether.session.SessionProvider;
import net.creeperhost.minetogether.session.data.mc.ProfileKeyPairResponse;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.UUID;

/**
 * Created by covers1624 on 24/8/23.
 */
public class MTSessionProvider implements SessionProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(MTSessionProvider.class);
    private static final String UA =
            "MineTogether-lib/" + MineTogetherLib.VERSION +
            " MineTogether-Community-mod/" + MineTogetherPlatform.getVersion() +
            " Minecraft/" + Platform.getMinecraftVersion() +
            " Modloader/" + ArchitecturyTarget.getCurrentTarget();
    private final Minecraft MC = Minecraft.m_91087_();
    private final User U = MC.m_91094_();
    private final String PN = U.m_92546_();
    private final UUID PI = U.m_240411_();

    // @formatter:off
    @Override public @Nullable UUID getUUID() { return PI; }
    @Override public String getUsername() { return PN; }
    @Override public @Nullable String beginAuth() throws IOException { return MojangUtils.joinServer(PI, U.m_92547_()); }
    @Override public @Nullable ProfileKeyPairResponse getProfileKeyPair() throws IOException { return MojangUtils.getProfileKeypair(U.m_92547_()); }
    @Override public void infoLog(String msg, Object... args) { LOGGER.info(msg, args); }
    @Override public void warnLog(String msg, Object... args) { LOGGER.warn(msg, args); }
    @Override public void errorLog(String msg, Object... args) { LOGGER.error(msg, args); }
    @Override public String describe() { return UA; }
    // @formatter:on
}

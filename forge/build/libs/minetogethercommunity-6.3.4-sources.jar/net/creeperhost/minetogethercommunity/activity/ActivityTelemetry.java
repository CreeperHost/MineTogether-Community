package net.creeperhost.minetogethercommunity.activity;

import com.google.common.hash.Hashing;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.architectury.event.events.client.ClientLifecycleEvent;
import dev.architectury.event.events.client.ClientPlayerEvent;
import dev.architectury.event.events.client.ClientTickEvent;
import dev.architectury.injectables.targets.ArchitecturyTarget;
import dev.architectury.platform.Platform;
import net.covers1624.quack.net.httpapi.EngineRequest;
import net.covers1624.quack.net.httpapi.EngineResponse;
import net.covers1624.quack.net.httpapi.HeaderList;
import net.covers1624.quack.net.httpapi.WebBody;
import net.creeperhost.minetogether.lib.web.WebConstants;
import net.creeperhost.minetogethercommunity.MineTogether;
import net.creeperhost.minetogethercommunity.MineTogetherPlatform;
import net.creeperhost.minetogethercommunity.config.LocalConfig;
import net.creeperhost.minetogethercommunity.util.ModPackInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.resources.language.ClientLanguage;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.network.protocol.game.ClientboundUpdateAdvancementsPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collection;
import java.util.HashMap;
import java.util.IllegalFormatException;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ActivityTelemetry {

    private static final Logger LOGGER = LogManager.getLogger();
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(new ThreadFactoryBuilder()
            .setNameFormat("mt-activity-telemetry")
            .setDaemon(true)
            .build());

    private static final long PREFERENCE_REFRESH_MS = 5 * 60 * 1000L;
    private static final long HEARTBEAT_MS = 60 * 1000L;
    private static final int MAX_PENDING_BATCHES = 128;

    // Retry policy: after a failed flush, wait with exponential backoff before retrying,
    // and give up entirely after too many consecutive failures (reset on auth change).
    private static final long RETRY_BASE_MS = 5 * 1000L;
    private static final long RETRY_MAX_MS = 5 * 60 * 1000L;
    private static final int MAX_CONSECUTIVE_FAILURES = 10;

    private static final Map<String, Object> KNOWN_ADVANCEMENTS = new HashMap<>();
    private static ActivityModels.QueueState state;
    private static volatile boolean enabled = true;
    private static volatile boolean preferenceRequestRunning = false;
    private static volatile boolean flushRunning = false;
    private static volatile boolean sendingDisabled = false;
    private static int consecutiveFailures = 0;
    private static long nextFlushAllowedAt = 0;
    private static volatile String currentAuthKey = "";
    private static long lastPreferenceRequest = 0;
    private static long lastHeartbeat = 0;
    private static long playtimeStarted = 0;
    private static boolean inWorld = false;
    private static boolean englishLanguageLoadAttempted = false;
    private static ClientLanguage englishLanguage;

    public static void init() {
        state = freshState();
        if (!currentAuthKey.isEmpty()) {
            applyAuthKey(currentAuthKey);
        }
        ClientTickEvent.CLIENT_POST.register(ActivityTelemetry::tick);
        ClientLifecycleEvent.CLIENT_STOPPING.register(ActivityTelemetry::stopping);
        ClientPlayerEvent.CLIENT_PLAYER_QUIT.register(player -> onWorldExit());
        refreshPreference();
    }

    public static void authChanged(Object token) {
        currentAuthKey = authKey(token);
        LOGGER.info("[MT-TELEMETRY-DEBUG] authChanged: authKey {} (empty means telemetry stays disabled)", currentAuthKey.isEmpty() ? "EMPTY" : "set (len=" + currentAuthKey.length() + ")");
        if (state == null) return;
        applyAuthKey(currentAuthKey);
        lastPreferenceRequest = 0;
        refreshPreference();
        flush();
    }

    public static void handleAdvancementPacket(ClientboundUpdateAdvancementsPacket packet) {
        int addedCount = 0;
        for (Object holder : asIterable(call(packet, "getAdded", "added"))) {
            Object id = call(holder, "id", "getId");
            if (id != null) {
                KNOWN_ADVANCEMENTS.put(id.toString(), holder);
                addedCount++;
            }
        }
        for (Object removed : asIterable(call(packet, "getRemoved", "removed"))) {
            KNOWN_ADVANCEMENTS.remove(removed.toString());
        }
        Map<?, ?> progress = asMap(call(packet, "getProgress", "progress"));
        boolean reset = Boolean.TRUE.equals(call(packet, "shouldReset", "reset"));
        int doneCount = 0;
        int skipped = 0;
        for (Map.Entry<?, ?> entry : progress.entrySet()) {
            if (Boolean.TRUE.equals(call(entry.getValue(), "isDone", "done"))) {
                String id = entry.getKey().toString();
                Object holder = KNOWN_ADVANCEMENTS.get(id);
                // Skip advancements with no DisplayInfo: these are recipe unlocks
                // (minecraft:recipes/...) and other hidden/functional advancements that never
                // appear in the GUI and carry no title/description, so they aren't achievements.
                if (!hasDisplay(holder)) {
                    skipped++;
                    continue;
                }
                queueAdvancement(id, holder, reset ? "snapshot" : "incremental");
                doneCount++;
            }
        }
        LOGGER.info("[MT-TELEMETRY-DEBUG] advancement packet: added={} progress={} queued={} skipped(no display, e.g. recipes)={} reset={}", addedCount, progress.size(), doneCount, skipped, reset);
    }

    private static boolean hasDisplay(Object holder) {
        if (holder == null) return false;
        Object advancement = call(holder, "value", "getValue");
        return unwrapOptional(call(advancement, "display", "getDisplay")) != null;
    }

    private static void tick(Minecraft mc) {
        long now = System.currentTimeMillis();
        if (now - lastPreferenceRequest > PREFERENCE_REFRESH_MS) {
            refreshPreference();
        }

        boolean currentlyInWorld = mc.f_91073_ != null && mc.f_91074_ != null;
        if (currentlyInWorld && !inWorld) {
            inWorld = true;
            playtimeStarted = now;
            lastHeartbeat = now;
        } else if (!currentlyInWorld && inWorld) {
            queuePlaytime(now);
            inWorld = false;
            playtimeStarted = 0;
            flush();
        } else if (currentlyInWorld && now - lastHeartbeat >= HEARTBEAT_MS) {
            queuePlaytime(now);
            playtimeStarted = now;
            lastHeartbeat = now;
            flush();
        } else if (hasPending()) {
            flush();
        }
    }

    private static void stopping(Minecraft mc) {
        onWorldExit();
    }

    // Called both on CLIENT_PLAYER_QUIT (quit to title / disconnect) and CLIENT_STOPPING (game close).
    // Queues any remaining playtime then submits a flush to the same single-threaded executor so it
    // runs after any in-flight async flush --- then blocks (up to 10 s) waiting for completion.
    // Because the executor is FIFO and single-threaded, this approach avoids the race condition
    // where flushRunning == true causes a blocking flush to return early.
    private static void onWorldExit() {
        long now = System.currentTimeMillis();
        if (inWorld) {
            queuePlaytime(now);
            inWorld = false;
            playtimeStarted = 0;
        }
        flushSync();
    }

    private static void refreshPreference() {
        if (preferenceRequestRunning) return;
        lastPreferenceRequest = System.currentTimeMillis();
        preferenceRequestRunning = true;
        EXECUTOR.execute(() -> {
            try {
                GetTelemetryPreferencesRequest.Response response = MineTogether.API.execute(new GetTelemetryPreferencesRequest()).apiResponse();
                enabled = response.enabled;
                LOGGER.info("[MT-TELEMETRY-DEBUG] preferences fetched: enabled={} hasAccount={}", response.enabled, response.hasAccount);
                if (!enabled) {
                    synchronized (ActivityTelemetry.class) {
                        state.pending.clear();
                    }
                }
            } catch (Throwable t) {
                LOGGER.warn("[MT-TELEMETRY-DEBUG] preferences fetch failed (enabled stays {}): {}", enabled, t.toString());
            } finally {
                preferenceRequestRunning = false;
            }
        });
    }

    private static boolean shouldSkipTelemetry() {
        if (!LocalConfig.instance().activityTelemetry) return true;
        Minecraft mc = Minecraft.m_91087_();
        if (mc.f_91074_ != null && mc.f_91074_.m_7500_()) return true;
        if (mc.m_91091_() && mc.m_91092_() != null && mc.m_91092_().m_129910_().m_5468_()) return true;
        return false;
    }

    private static void queuePlaytime(long now) {
        if (!enabled || shouldSkipTelemetry() || playtimeStarted <= 0 || now <= playtimeStarted) return;
        int deltaSeconds = (int) Math.min((now - playtimeStarted) / 1000L, 600L);
        if (deltaSeconds <= 0) return;

        ActivityModels.Batch batch = newBaseBatch();
        batch.playtime = new ActivityModels.Playtime();
        batch.playtime.from = playtimeStarted;
        batch.playtime.to = now;
        batch.playtime.deltaSeconds = deltaSeconds;
        queue(batch);
    }

    public static void queueQuestAsync(String questId, String rawTitle, String rawDescription, String iconItemId) {
        queueQuestAsync("ftbquests", questId, rawTitle, rawDescription, iconItemId);
    }

    public static void queueQuestAsync(String provider, String questId, String rawTitle, String rawDescription, String iconItemId) {
        EXECUTOR.execute(() -> {
            try {
                queueQuest(provider, questId, rawTitle, rawDescription, iconItemId);
            } catch (Throwable t) {
                LOGGER.warn("[MT-TELEMETRY-DEBUG] async quest queue threw", t);
            }
        });
    }

    public static void queueQuest(String questId, String rawTitle, String rawDescription, String iconItemId) {
        queueQuest("ftbquests", questId, rawTitle, rawDescription, iconItemId);
    }

    public static void queueQuest(String provider, String questId, String rawTitle, String rawDescription, String iconItemId) {
        if (!enabled || shouldSkipTelemetry()) return;
        String safeProvider = safe(provider);
        if (safeProvider.isEmpty()) safeProvider = "unknown";

        ActivityModels.Metadata metadata = new ActivityModels.Metadata();
        metadata.type = "quest";
        metadata.provider = safeProvider;
        metadata.contentId = safe(questId);
        metadata.titleEn = safe(rawTitle);
        metadata.descriptionEn = safe(rawDescription);
        metadata.iconItemId = safe(iconItemId);
        metadata.locale = "en_us";
        metadata.metadataRef = hash("quest:" + safeProvider + ":" + metadata.contentId + ":" + metadata.titleEn + ":" + metadata.descriptionEn);

        ActivityModels.QuestEvent event = new ActivityModels.QuestEvent();
        event.metadataRef = metadata.metadataRef;
        event.provider = safeProvider;
        event.completedAt = System.currentTimeMillis();
        event.source = "incremental";
        event.eventId = hash(state.clientSessionId + ":" + currentWorld().key + ":" + modpackIdentity() + ":" + safeProvider + ":" + metadata.contentId);

        ActivityModels.Batch batch = newBaseBatch();
        batch.metadata.add(metadata);
        batch.questCompletions.add(event);
        LOGGER.info("[MT-TELEMETRY-DEBUG] queueQuest id={} title={} descLen={}", questId, metadata.titleEn, metadata.descriptionEn.length());
        queue(batch);
        flush();
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static void queueAdvancement(String advancementId, Object holder, String source) {
        if (!enabled || shouldSkipTelemetry()) return;

        ActivityModels.Metadata metadata = metadataForAdvancement(advancementId, holder);
        ActivityModels.AdvancementEvent event = new ActivityModels.AdvancementEvent();
        event.metadataRef = metadata.metadataRef;
        event.completedAt = System.currentTimeMillis();
        event.source = source;
        event.eventId = hash(state.clientSessionId + ":" + currentWorld().key + ":" + modpackIdentity() + ":" + advancementId);

        ActivityModels.Batch batch = newBaseBatch();
        batch.metadata.add(metadata);
        batch.advancements.add(event);
        LOGGER.info("[MT-TELEMETRY-DEBUG] queueAdvancement id={} source={} title={}", advancementId, source, metadata.titleEn);
        queue(batch);
        flush();
    }

    private static synchronized void queue(ActivityModels.Batch batch) {
        if (state.authKey == null || state.authKey.isEmpty()) {
            LOGGER.warn("[MT-TELEMETRY-DEBUG] queue() dropped batch: authKey is empty (not authenticated / JWT had no sha/sub claim)");
            return;
        }
        batch.sequence = state.nextSequence++;
        batch.sentAt = System.currentTimeMillis();
        state.pending.add(batch);
        while (state.pending.size() > MAX_PENDING_BATCHES) {
            state.pending.remove(0);
        }
    }

    private static void flush() {
        if (!markFlushRunning(false)) return;
        EXECUTOR.execute(() -> {
            boolean success = false;
            try {
                success = drainQueue();
            } catch (Throwable t) {
                LOGGER.warn("[MT-TELEMETRY-DEBUG] flush drainQueue threw", t);
            } finally {
                recordFlushResult(success);
                flushRunning = false;
            }
        });
    }

    // Submits a flush task to the same single-threaded executor and waits up to 10 s.
    // Running on the executor guarantees we queue behind any in-flight async flush,
    // so flushRunning will be false by the time our task executes.
    private static void flushSync() {
        try {
            EXECUTOR.submit(() -> {
                if (!markFlushRunning(true)) return;
                boolean success = false;
                try {
                    success = drainQueue();
                } catch (Throwable ignored) {
                } finally {
                    recordFlushResult(success);
                    flushRunning = false;
                }
            }).get(10, TimeUnit.SECONDS);
        } catch (Exception ignored) {
        }
    }

    private static synchronized boolean markFlushRunning(boolean ignoreBackoff) {
        if (!enabled || flushRunning || sendingDisabled) return false;
        if (state.authKey == null || state.authKey.isEmpty()) return false;
        if (!ignoreBackoff && System.currentTimeMillis() < nextFlushAllowedAt) return false;
        flushRunning = true;
        return true;
    }

    private static synchronized void recordFlushResult(boolean success) {
        if (success) {
            consecutiveFailures = 0;
            nextFlushAllowedAt = 0;
            return;
        }
        consecutiveFailures++;
        if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
            sendingDisabled = true;
            nextFlushAllowedAt = 0;
            LOGGER.warn("MineTogether activity telemetry: giving up after {} consecutive failed batches (will retry next session).", consecutiveFailures);
            return;
        }
        long delay = Math.min(RETRY_BASE_MS << (consecutiveFailures - 1), RETRY_MAX_MS);
        nextFlushAllowedAt = System.currentTimeMillis() + delay;
        LOGGER.info("[MT-TELEMETRY-DEBUG] flush failed ({}/{}), backing off {}ms", consecutiveFailures, MAX_CONSECUTIVE_FAILURES, delay);
    }

    private static synchronized void resetBackoff() {
        consecutiveFailures = 0;
        nextFlushAllowedAt = 0;
        sendingDisabled = false;
    }

    /**
     * Drains pending batches to the server. Returns {@code true} if the queue was fully
     * drained (or already empty), {@code false} if a batch was rejected and the drain
     * stopped (signalling the caller to back off). Throws on transport failure.
     */
    private static boolean drainQueue() throws IOException {
        while (true) {
            ActivityModels.Batch batch;
            synchronized (ActivityTelemetry.class) {
                if (state.pending.isEmpty()) return true;
                batch = state.pending.get(0);
            }
            String url = WebConstants.CH_API + "minetogether/activity/batch";
            String json = GSON.toJson(batch);
            LOGGER.info("[MT-TELEMETRY-DEBUG] POST batch seq={} advancements={} playtime={} bodyBytes={} -> {}",
                    batch.sequence, batch.advancements.size(), batch.playtime != null, json.getBytes(StandardCharsets.UTF_8).length, url);

            // Raw request so we can log the return code + raw response body, before
            // any typed parsing (the typed parse throws when the server omits the "status" field,
            // which hides what actually came back). Log only auth header lengths; the header
            // values are credentials.
            EngineRequest request = MineTogether.WEB_ENGINE.newRequest();
            request.method("POST", WebBody.string(json, WebConstants.JSON));
            request.url(url);
            HeaderList authHeaders = MineTogether.AUTH.getAuthHeaders();
            for (String name : new String[]{"Authorization", "Fingerprint", "Identifier"}) {
                String value = authHeaders.get(name);
                request.header(name, value == null ? "" : value);
                LOGGER.info("[MT-TELEMETRY-DEBUG] auth header {}: {}", name, value == null ? "<MISSING>" : "len=" + value.length());
            }

            int statusCode;
            String contentType = "<none>";
            String rawBody = "<none>";
            try (EngineResponse response = request.execute()) {
                statusCode = response.statusCode();
                WebBody body = response.body();
                if (body != null) {
                    contentType = String.valueOf(body.contentType());
                    try (InputStream in = body.open()) {
                        rawBody = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                    }
                }
            }
            LOGGER.info("[MT-TELEMETRY-DEBUG] RAW response: returnCode={} contentType={} body={}", statusCode, contentType, rawBody);

            boolean accepted = statusCode >= 200 && statusCode < 300 && responseAccepted(rawBody);
            if (!accepted) {
                LOGGER.warn("[MT-TELEMETRY-DEBUG] batch NOT accepted (returnCode={}), leaving in queue (size={})", statusCode, state.pending.size());
                return false;
            }
            synchronized (ActivityTelemetry.class) {
                state.pending.remove(0);
            }
            LOGGER.info("[MT-TELEMETRY-DEBUG] batch seq={} accepted & removed from queue", batch.sequence);
        }
    }

    private static boolean responseAccepted(String rawBody) {
        try {
            Map<?, ?> map = GSON.fromJson(rawBody, Map.class);
            if (map == null) return false;
            return "success".equals(map.get("status")) && !Boolean.FALSE.equals(map.get("accepted"));
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static synchronized boolean hasPending() {
        return state != null && !state.pending.isEmpty();
    }

    private static ActivityModels.Batch newBaseBatch() {
        ActivityModels.Batch batch = new ActivityModels.Batch();
        batch.clientSessionId = state.clientSessionId;
        batch.modpack = currentModpack();
        batch.world = currentWorld();
        return batch;
    }

    private static ActivityModels.Metadata metadataForAdvancement(String id, Object holder) {
        ActivityModels.Metadata metadata = new ActivityModels.Metadata();
        metadata.type = "advancement";
        metadata.provider = "vanilla";
        metadata.contentId = id;
        metadata.locale = "en_us";

        if (holder != null) {
            Object advancement = call(holder, "value", "getValue");
            Object display = unwrapOptional(call(advancement, "display", "getDisplay"));
            if (display != null) {
                fillDisplay(metadata, display);
            }
        }
        metadata.metadataRef = hash(metadata.type + ":" + metadata.provider + ":" + metadata.contentId + ":" + metadata.titleKey + ":" + metadata.descriptionKey + ":" + metadata.titleEn + ":" + metadata.descriptionEn);
        return metadata;
    }

    private static void fillDisplay(ActivityModels.Metadata metadata, Object display) {
        Object titleObj = call(display, "getTitle", "title");
        Object descriptionObj = call(display, "getDescription", "description");
        if (titleObj instanceof Component title) {
            metadata.titleKey = translationKey(title);
            metadata.titleEn = englishText(title);
        }
        if (descriptionObj instanceof Component description) {
            metadata.descriptionKey = translationKey(description);
            metadata.descriptionEn = englishText(description);
        }
        Object iconObj = call(display, "getIcon", "icon");
        if (iconObj instanceof ItemStack stack) {
            metadata.iconItemId = BuiltInRegistries.f_257033_.m_7981_(stack.m_41720_()).toString();
        }
        Object frame = call(display, "getFrame", "frame");
        if (frame != null) {
            Object name = call(frame, "getName", "getSerializedName");
            metadata.frameOrType = name == null ? frame.toString() : name.toString();
        }
    }

    private static String translationKey(Component component) {
        if (component.m_214077_() instanceof TranslatableContents contents) {
            return contents.m_237508_();
        }
        return "";
    }

    private static String englishText(Component component) {
        if (component.m_214077_() instanceof TranslatableContents contents) {
            String fallback = contents.m_264577_();
            if (fallback == null || fallback.isEmpty()) {
                fallback = component.getString();
            }

            ClientLanguage language = englishLanguage();
            String value = language == null ? fallback : language.m_118919_(contents.m_237508_(), fallback);
            Object[] args = contents.m_237523_();
            if (args.length == 0) {
                return value;
            }

            Object[] formattedArgs = new Object[args.length];
            for (int i = 0; i < args.length; i++) {
                formattedArgs[i] = args[i] instanceof Component child ? englishText(child) : String.valueOf(args[i]);
            }

            try {
                return String.format(Locale.ROOT, value, formattedArgs);
            } catch (IllegalFormatException ignored) {
                return fallback;
            }
        }
        return component.getString();
    }

    private static ClientLanguage englishLanguage() {
        if (!englishLanguageLoadAttempted) {
            englishLanguageLoadAttempted = true;
            try {
                englishLanguage = ClientLanguage.m_264420_(Minecraft.m_91087_().m_91098_(), List.of("en_us"), false);
            } catch (Throwable ex) {
                LOGGER.warn("Failed to load en_us language resources for MineTogether activity metadata.", ex);
            }
        }
        return englishLanguage;
    }

    private static ActivityModels.Modpack currentModpack() {
        ActivityModels.Modpack modpack = new ActivityModels.Modpack();
        ModPackInfo.VersionInfo info = ModPackInfo.getInfo();
        if (!info.ftbPackID.isEmpty()) {
            modpack.source = "ftb";
            modpack.packId = info.ftbPackID;
            modpack.versionId = info.base64FTBID;
        } else if (!info.curseID.isEmpty()) {
            modpack.source = "curse";
            modpack.packId = info.curseID;
        }
        modpack.websiteId = info.websiteID;
        modpack.minecraftVersion = Platform.getMinecraftVersion();
        modpack.loader = ArchitecturyTarget.getCurrentTarget();
        modpack.modVersion = MineTogetherPlatform.getVersion();
        return modpack;
    }

    private static String modpackIdentity() {
        ActivityModels.Modpack modpack = currentModpack();
        return modpack.source + ":" + modpack.packId + ":" + modpack.versionId + ":" + modpack.websiteId + ":" + modpack.minecraftVersion + ":" + modpack.loader + ":" + modpack.modVersion;
    }

    private static ActivityModels.World currentWorld() {
        Minecraft mc = Minecraft.m_91087_();
        ActivityModels.World world = new ActivityModels.World();
        if (mc.m_91091_() && mc.m_91092_() != null) {
            world.kind = "singleplayer";
            world.key = hash("singleplayer:" + mc.m_91092_().m_129910_().m_5462_());
        } else {
            ServerData server = mc.m_91089_();
            world.kind = "multiplayer";
            world.key = hash("multiplayer:" + (server == null ? "unknown" : server.f_105363_));
        }
        return world;
    }

    private static ActivityModels.QueueState freshState() {
        ActivityModels.QueueState fresh = new ActivityModels.QueueState();
        fresh.clientSessionId = UUID.randomUUID().toString();
        return fresh;
    }

    private static synchronized void applyAuthKey(String authKey) {
        if (authKey == null || authKey.isEmpty()) {
            state.pending.clear();
            state.authKey = "";
            return;
        }
        if (!authKey.equals(state.authKey)) {
            state.pending.clear();
            state.clientSessionId = UUID.randomUUID().toString();
            state.nextSequence = 1;
            state.authKey = authKey;
            resetBackoff();
        }
    }

    private static String authKey(Object token) {
        if (token == null) return "";
        String compact = token.toString();
        String[] parts = compact.split("\\.");
        if (parts.length < 2) return "";
        try {
            String payload = new String(Base64.getUrlDecoder().decode(padBase64(parts[1])), StandardCharsets.UTF_8);
            Map<?, ?> claims = GSON.fromJson(payload, Map.class);
            Object sha = claims == null ? null : claims.get("sha");
            if (sha == null) sha = claims == null ? null : claims.get("sub");
            return sha == null ? "" : hash(sha.toString());
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static String padBase64(String value) {
        int remainder = value.length() % 4;
        if (remainder == 0) return value;
        return value + "=".repeat(4 - remainder);
    }

    private static String hash(String value) {
        return Hashing.sha256().hashString(value, StandardCharsets.UTF_8).toString();
    }

    private static Object call(Object target, String... methodNames) {
        if (target == null) return null;
        for (String methodName : methodNames) {
            try {
                Method method = target.getClass().getMethod(methodName);
                return method.invoke(target);
            } catch (ReflectiveOperationException ignored) {
            }
        }
        return null;
    }

    private static Object unwrapOptional(Object value) {
        if (value instanceof Optional<?> optional) {
            return optional.orElse(null);
        }
        return value;
    }

    private static Iterable<?> asIterable(Object value) {
        if (value instanceof Iterable<?> iterable) {
            return iterable;
        }
        return java.util.List.of();
    }

    private static Map<?, ?> asMap(Object value) {
        if (value instanceof Map<?, ?> map) {
            return map;
        }
        return Map.of();
    }
}

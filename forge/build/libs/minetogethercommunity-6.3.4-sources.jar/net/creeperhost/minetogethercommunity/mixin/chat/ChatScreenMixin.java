package net.creeperhost.minetogethercommunity.mixin.chat;

import net.creeperhost.minetogethercommunity.MineTogether;
import net.creeperhost.minetogethercommunity.chat.gui.ChatScreenInjection;
import net.creeperhost.minetogethercommunity.chat.gui.FriendChatGui;
import net.creeperhost.minetogethercommunity.chat.ingame.MTChatComponent;
import net.creeperhost.minetogethercommunity.config.LocalConfig;
import net.creeperhost.minetogethercommunity.gui.PreviewElement;
import net.creeperhost.minetogethercommunity.gui.SettingGui;
import net.creeperhost.minetogether.lib.chat.irc.IrcState;
import net.creeperhost.minetogether.lib.chat.message.Message;
import net.creeperhost.minetogethercommunity.polylib.gui.IconButton;
import net.creeperhost.minetogethercommunity.polylib.gui.RadioButton;
import net.creeperhost.minetogethercommunity.polylib.gui.SlideButton;
import net.creeperhost.minetogethercommunity.chat.*;
import net.creeperhost.polylib.client.modulargui.ModularGui;
import net.creeperhost.polylib.client.modulargui.ModularGuiInjector;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.gui.components.CommandSuggestions;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.net.URL;

/**
 * Created by covers1624 on 5/8/22.
 */
@Mixin(ChatScreen.class)
abstract class ChatScreenMixin extends Screen {

    private static final Logger LOGGER = LogManager.getLogger();

    private RadioButton vanillaChatButton;
    private RadioButton mtChatButton;
    private RadioButton groupChatButton;
    private SlideButton chatScaleSlider;
    private SlideButton chatWidthSlider;
    private SlideButton chatHeightSlider;
    private IconButton settingsButton;

    @Nullable
    private Message clickedMessage;

    @Shadow
    protected EditBox input;

    @Shadow
    CommandSuggestions commandSuggestions;

    @Shadow private String initial;

    @Shadow @Nullable protected abstract Style getComponentStyleAt(double d, double e);

    private Button newUserButton;
    private Button disableButton;

    protected ChatScreenMixin(Component component) {
        super(component);
    }

    @Inject(
            method = "init",
            at = @At("TAIL")
    )
    private void onInit(CallbackInfo ci) {
        Minecraft mc = Minecraft.m_91087_();
        if (!LocalConfig.instance().chatEnabled || mc.f_91066_.f_92062_) return;
        input.m_94144_(initial);

        ChatComponent chat = mc.f_91065_.m_93076_();
        float cScale = (float) chat.m_93815_();
        int cWidth = Mth.m_14167_((float) chat.m_93813_() + (12 * cScale)); //Vanilla does some wired s%$#. This mostly accounts for it.
        int cHeight = Mth.m_14167_(chat.m_93814_() * cScale);

        vanillaChatButton = m_142416_(new RadioButton(0, 0, 12, 100, mc.m_91090_() ? Component.m_237115_("minetogether:ingame.chat.local") : Component.m_237115_("minetogether:ingame.chat.server")))
                .withAutoScaleText(3)
                .withVerticalText()
                .selectedSupplier(() -> MineTogetherChat.getTarget() == ChatTarget.VANILLA)
                .onPressed(e -> MineTogetherChat.setTarget(ChatTarget.VANILLA))
                .onRelease(() -> m_7522_(input));

        mtChatButton = m_142416_(new RadioButton(0, 0, 12, 100, Component.m_237115_("minetogether:ingame.chat.global")))
                .withAutoScaleText(3)
                .withVerticalText()
                .selectedSupplier(() -> MineTogetherChat.getTarget() == ChatTarget.PUBLIC)
                .onPressed(e -> MineTogetherChat.setTarget(ChatTarget.PUBLIC))
                .onRelease(() -> m_7522_(input));

        groupChatButton = m_142416_(new RadioButton(0, 0, 12, 100, Component.m_237115_("minetogether:ingame.chat.group")))
                .withAutoScaleText(3)
                .withVerticalText()
                .selectedSupplier(() -> MineTogetherChat.getTarget() == ChatTarget.GROUP)
                .onPressed(e -> MineTogetherChat.setTarget(ChatTarget.GROUP))
                .onRelease(() -> m_7522_(input));

        settingsButton = m_142416_(new IconButton(0, 0, 12, 12, new ResourceLocation(MineTogether.MOD_ID, "textures/gui/buttons/gear.png"), e -> mc.m_91152_(new SettingGui.Screen(mc.f_91080_))));

        chatScaleSlider = m_142416_(new SlideButton(0, 0, 12, 200))
                .setDynamicMessage(() -> Component.m_237110_("options.percent_value", Component.m_237115_("options.chat.scale"), (int) (mc.f_91066_.m_232110_().m_231551_() * 100.0)))
                .bindValue(() -> mc.f_91066_.m_232110_().m_231551_(), value -> {
                    mc.f_91066_.m_232110_().m_231514_(value);
                    updateButtons();
                })
                .setRange(0.25, 1)
                .withTextScale(0.75F)
                .onRelease(() -> m_7522_(input))
                .setEnabled(() -> commandSuggestions.f_93866_ == null && LocalConfig.instance().chatSettingsSliders)
                .withAutoScaleText(3);

        chatWidthSlider = m_142416_(new SlideButton(0, 0, 12, 200))
                .setDynamicMessage((newValue) -> Component.m_237110_("options.pixel_value", Component.m_237115_("options.chat.width"), ChatComponent.m_93798_(newValue)))
                .bindValue(() -> mc.f_91066_.m_232113_().m_231551_(), value -> {
                    mc.f_91066_.m_232113_().m_231514_(value);
                    updateButtons();
                })
                .withTextScale(0.75F)
                .onRelease(() -> m_7522_(input))
                .setApplyOnRelease(true)
                .setEnabled(() -> commandSuggestions.f_93866_ == null && LocalConfig.instance().chatSettingsSliders)
                .withAutoScaleText(3);

        chatHeightSlider = m_142416_(new SlideButton(0, 0, 12, 200))
                .setDynamicMessage(() -> Component.m_237110_("options.pixel_value", Component.m_237115_("options.chat.height.focused"), ChatComponent.m_93811_(mc.f_91066_.m_232117_().m_231551_())))
                .bindValue(() -> mc.f_91066_.m_232117_().m_231551_(), value -> {
                    mc.f_91066_.m_232117_().m_231514_(value);
                    updateButtons();
                })
                .withTextScale(0.75F)
                .onRelease(() -> m_7522_(input))
                .setEnabled(() -> commandSuggestions.f_93866_ == null && LocalConfig.instance().chatSettingsSliders)
                .withAutoScaleText(3);

        updateButtons();

        newUserButton = m_7787_(Button.m_253074_(Component.m_237113_("Join " + ChatStatistics.onlineCount + " online users now!"), e -> {
                            MineTogetherChat.setNewUserResponded();
                            m_7522_(input);
                        })
                        .m_252987_(6, f_96544_ - ((cHeight + 80) / 2) + 45, cWidth - 2, 20)
                        .m_253136_()
        );
        disableButton = m_7787_(Button.m_253074_(Component.m_237113_("Don't ask me again."), e -> {
                            MineTogetherChat.disableChat();
                            LocalConfig.instance().chatEnabled = false;
                            LocalConfig.save();
                            MineTogetherChat.setNewUserResponded();
                            m_169413_();
                            m_7522_(input);
                        })
                        .m_252987_(6, f_96544_ - ((cHeight + 80) / 2) + 70, cWidth - 2, 20)
                        .m_253136_()
        );
        newUserButton.f_93624_ = false;
        disableButton.f_93624_ = false;

        if (MineTogetherChat.isNewUser() && MineTogetherChat.getTarget() == ChatTarget.PUBLIC) {
            ChatStatistics.pollStats();
            newUserButton.f_93624_ = true;
            disableButton.f_93624_ = true;
        }

        switchToVanillaIfCommand();

        ModularGui gui = ModularGuiInjector.getActiveGui();
        if (gui != null && gui.getProvider() instanceof ChatScreenInjection) {
            ChatScreenInjection.setURLProvider(this::getUrlUnderMouse);
        }
    }

    private void updateButtons() {
        Minecraft mc = Minecraft.m_91087_();
        if (!LocalConfig.instance().chatEnabled || mc.f_91066_.f_92062_) {
            return;
        }
        ChatComponent chat = mc.f_91065_.m_93076_();
        float cScale = (float) chat.m_93815_();
        int cWidth = Mth.m_14167_((float) chat.m_93813_() + (12 * cScale)); //Vanilla does some wired s%$#. This mostly accounts for it.
        int cHeight = Mth.m_14167_(chat.m_93814_() * cScale) - 12;
        int guiHeight = f_96544_;
        int cMaxYPos = guiHeight - 40;

        boolean groupChat = MineTogetherChat.CHAT_STATE.profileManager.getPrivateGroup() != null;

        int vanillaYPos = cMaxYPos - cHeight - 12;
        int vanillaHeight = groupChat ? cHeight / 3 : cHeight / 2;
        vanillaChatButton.updateBounds(cWidth, vanillaYPos, 12, vanillaHeight);

        int mtYPos = vanillaYPos + vanillaHeight;
        int mtHeight = groupChat ? cHeight / 3 : cMaxYPos - mtYPos - 12;
        mtChatButton.updateBounds(cWidth, mtYPos, 12, mtHeight);

        int groupYPos = mtYPos + mtHeight;
        int groupHeight = groupChat ? cMaxYPos - groupYPos - 12 : 0;
        groupChatButton.updateBounds(cWidth, groupYPos, 12, groupHeight);
        groupChatButton.f_93624_ = groupChat;

        settingsButton.updateBounds(cWidth, groupChat ? groupYPos + groupHeight : mtYPos + mtHeight, 12, 12);

        int sliderWidth = cWidth / 3;
        chatWidthSlider.updateBounds(0, cMaxYPos + 2, sliderWidth, 10);
        chatHeightSlider.updateBounds(sliderWidth + 2, cMaxYPos + 2, sliderWidth, 10);
        chatScaleSlider.updateBounds((sliderWidth * 2) + 4, cMaxYPos + 2, cWidth - (sliderWidth * 2) - 4, 10);
    }

    @Inject(
            method = "mouseClicked",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onMouseClicked(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        //Should be able to do this with a client command, but client commands dont work through the "RUN_COMMAND" click event.
        Style style = getComponentStyleAt(mouseX, mouseY);
        if (style != null) {
            ClickEvent clickEvent = style.m_131182_();
            if (clickEvent instanceof FriendChatNotifier.OpenFriendEvent event) {
                FriendChatGui.setSelected(event.profile);
                Minecraft.m_91087_().m_91152_(new FriendChatGui.Screen(null));
                cir.setReturnValue(true);
            }
        }

        if (!LocalConfig.instance().chatEnabled || Minecraft.m_91087_().f_91066_.f_92062_) return;

        //Link clicks get blocked by our tryClickMTChat function, so we need to do it ourselves here.
        if (MineTogetherChat.getTarget() == ChatTarget.PUBLIC && button == 0) {
            if (style != null && this.m_5561_(style)) {
                this.initial = this.input.m_94155_();
                cir.setReturnValue(true);
            }
        }

        if (MineTogetherChat.getTarget() == ChatTarget.PUBLIC && tryClickMTChat(MineTogetherChat.publicChat, mouseX, mouseY, button)) {
            cir.setReturnValue(true);
        }
    }

    @Override
    public boolean m_6348_(double d, double e, int i) {
        Minecraft mc = Minecraft.m_91087_();
        if (!LocalConfig.instance().chatEnabled || mc.f_91066_.f_92062_) {
            return super.m_6348_(d, e, i);
        }

        //Needed because vanilla does not bother to send release if the mouse is not over the component.
        chatWidthSlider.m_6348_(d, e, i);
        chatHeightSlider.m_6348_(d, e, i);
        chatScaleSlider.m_6348_(d, e, i);

        //Ensure input box is always focused after input.
        m_7522_(input);
        return super.m_6348_(d, e, i);
    }

    @Override
    public boolean m_7920_(int i, int j, int k) {
        //Prevent focus from being directed away from text box via arrow keys
        m_7522_(input);
        return super.m_7920_(i, j, k);
    }

    @Inject(
            method = "render",
            at = @At("TAIL")
    )
    private void onRender(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
        if (MineTogetherChat.getTarget() == ChatTarget.PUBLIC && MineTogetherChat.isNewUser()) {
            graphics.m_280168_().m_85836_();
            graphics.m_280168_().m_252880_(0, 0, 100); // Push it forward a little bit so It's actually above the text.

            ChatComponent chatComponent = MineTogetherChat.publicChat;
            int y = f_96544_ - 43 - (f_96541_.f_91062_.f_92710_ * Math.max(Math.min(chatComponent.m_93797_().size(), chatComponent.m_93816_()), 20));
            graphics.m_280509_(0, y, chatComponent.m_93813_() + 6, chatComponent.m_93814_() + 10 + y, 0x99000000);

            graphics.m_280653_(f_96547_, Component.m_237115_("minetogether:new_user.1"), (chatComponent.m_93813_() / 2) + 3, f_96544_ - ((chatComponent.m_93814_() + 80) / 2), 0xFFFFFF);
            graphics.m_280653_(f_96547_, Component.m_237115_("minetogether:new_user.2"), (chatComponent.m_93813_() / 2) + 3, f_96544_ - ((chatComponent.m_93814_() + 80) / 2) + 10, 0xFFFFFF);
            graphics.m_280653_(f_96547_, Component.m_237115_("minetogether:new_user.3"), (chatComponent.m_93813_() / 2) + 3, f_96544_ - ((chatComponent.m_93814_() + 80) / 2) + 20, 0xFFFFFF);
            graphics.m_280653_(f_96547_, Component.m_237110_("minetogether:new_user.4", ChatStatistics.userCount), (chatComponent.m_93813_() / 2) + 3, f_96544_ - ((chatComponent.m_93814_() + 80) / 2) + 30, 0xFFFFFF);

            // Render these manually after the grey-out, so they are on top of it.
            newUserButton.m_88315_(graphics, mouseX, mouseY, partialTicks);
            disableButton.m_88315_(graphics, mouseX, mouseY, partialTicks);
            graphics.m_280168_().m_85849_();
        }
    }

    @Override
    public void m_86600_() {
        switchToVanillaIfCommand();

        if (groupChatButton != null && groupChatButton.f_93624_ == (MineTogetherChat.CHAT_STATE.profileManager.getPrivateGroup() == null)) {
            updateButtons();
        }

        // If we are the vanilla chat, set things editable, and bail out.
        if (MineTogetherChat.getTarget() == ChatTarget.VANILLA) {
            input.m_94186_(true);
            input.m_94167_("");
            return;
        }

        if (MineTogetherChat.isNewUser()) {
            newUserButton.f_93624_ = true;
            disableButton.f_93624_ = true;
            input.m_94186_(false);
            return;
        }

        IrcState state = MineTogetherChat.CHAT_STATE.ircClient.getState();
        if (state != IrcState.CONNECTED) {
            input.m_94186_(false);
            input.m_94167_(Component.m_237115_(ChatConstants.STATE_SUGGESTION_LOOKUP.get(state)).getString());
            return;
        }

        input.m_94186_(true);
        input.m_94167_("");
    }

    private boolean tryClickMTChat(MTChatComponent mtChat, double mouseX, double mouseY, int button) {
        if (!mtChat.handleClick(mouseX, mouseY)) return false;

        Message message = mtChat.getClickedMessage();
        if (message == null) return false;

        ModularGui gui = ModularGuiInjector.getActiveGui();
        if (gui != null && gui.getProvider() instanceof ChatScreenInjection injection && injection.canShowDialog()) {
            clickedMessage = message;
            mtChat.clearClickedMessage();
            injection.openMessageDialog(clickedMessage, input, mouseX, mouseY, button);
            return true;
        }
        return false;
    }

    @Nullable
    private PreviewElement.URLInfo getUrlUnderMouse(double mouseX, double mouseY) {
        if (MineTogetherChat.getTarget() != ChatTarget.PUBLIC) return null;

        Style style = MineTogetherChat.publicChat.getStyleUnderMouse(mouseX, mouseY);
        URL url = PreviewElement.urlFromStyle(style);
        if (url == null) return null;
        Message message = MineTogetherChat.publicChat.getMessageUnderMouse(mouseX, mouseY);
        return new PreviewElement.URLInfo(url, message != null && message.sender == null);
    }

    @Inject(
            method = "handleChatInput",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onHandleChatInput(String message, boolean bl, CallbackInfoReturnable<Boolean> cir) {
        String normalized = normalizeChatMessage(message);
        if (MineTogetherChat.getTarget() == ChatTarget.PUBLIC && !normalized.isEmpty()) {
            MineTogetherChat.publicChat.m_93783_(normalized);
            cir.setReturnValue(true);
        }
    }

    @Shadow public abstract String normalizeChatMessage(String string);

    //TODO looks like the code this references has been completely removed. Not sure if this is going to be an issue.
//    @Inject(
//            method = "sendsChatPreviewRequests",
//            at = @At("HEAD"),
//            cancellable = true
//    )
//    private void onSendsChatPreviewRequests(CallbackInfoReturnable<Boolean> cir) {
//        if (MineTogetherChat.getTarget() != ChatTarget.VANILLA) {
//            cir.setReturnValue(false);
//        }
//    }

    private boolean switchToVanillaIfCommand() {
        if (MineTogetherChat.getTarget() == ChatTarget.VANILLA) return false;
        if (!input.m_94155_().startsWith("/")) return false;

        MineTogetherChat.setTarget(ChatTarget.VANILLA);
        return true;
    }
}

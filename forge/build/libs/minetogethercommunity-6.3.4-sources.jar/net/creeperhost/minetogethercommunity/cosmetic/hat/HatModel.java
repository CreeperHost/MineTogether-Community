package net.creeperhost.minetogethercommunity.cosmetic.hat;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;

public class HatModel extends Model {

    private final ModelPart hat;

    public HatModel(Hat hat) {
        super(RenderType::m_110458_);
        if (hat.isJsonModel()) {
            this.hat = null;
            return;
        }

        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();

        // A single "hat" part whose children are the individual Techne shapes.
        // hat.render() recurses into all children automatically.
        PartDefinition hatPart = root.m_171599_("hat", CubeListBuilder.m_171558_(), PartPose.f_171404_);

        int idx = 0;
        for (HatCuboid c : hat.cuboids()) {
            // Raw Techne values - no coordinate transformation.
            // HatLayer's scale(-1,-1,1) replicates the old iChunUtil convention.
            CubeListBuilder builder = CubeListBuilder.m_171558_()
                    .m_171514_(c.texU(), c.texV())
                    .m_171481_(c.x(), c.y(), c.z(), c.sizeX(), c.sizeY(), c.sizeZ());

            // Position = rotation pivot; Rotation = per-shape rotation angles.
            PartPose pose = PartPose.m_171423_(
                    c.pivotX(), c.pivotY(), c.pivotZ(),
                    c.rotX(),   c.rotY(),   c.rotZ());

            hatPart.m_171599_("shape" + idx++, builder, pose);
        }

        this.hat = LayerDefinition.m_171565_(mesh, hat.texWidth(), hat.texHeight())
                .m_171564_()
                .m_171324_("hat");
    }

    @Override
    public void m_7695_(PoseStack poseStack, VertexConsumer consumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        if (hat == null) return;
        hat.m_104306_(poseStack, consumer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

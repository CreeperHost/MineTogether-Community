package net.creeperhost.minetogethercommunity.cosmetic.wing;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.creeperhost.minetogethercommunity.cosmetic.CosmeticSelections;
import net.creeperhost.minetogethercommunity.cosmetic.PlayerCosmeticCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;

public class WingLayer<T extends AbstractClientPlayer> extends RenderLayer<T, PlayerModel<T>> {

    public WingLayer(RenderLayerParent<T, PlayerModel<T>> renderer) {
        super(renderer);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, T player,
                       float limbSwing, float limbSwingAmount, float partialTicks,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        String wingId;
        if (player == Minecraft.m_91087_().f_91074_) {
            wingId = CosmeticSelections.instance().selectedWingId;
        } else {
            CosmeticSelections selections = PlayerCosmeticCache.get(player.m_20148_());
            if (selections == null) return;
            wingId = selections.selectedWingId;
        }
        if (wingId == null || wingId.isEmpty()) return;

        Wing wing = WingRegistry.getLoaded(wingId);
        if (wing == null) return;

        boolean flying = player.m_150110_().f_35935_ || player.f_19789_ > 0.0F;
        WingAnimation animation = wing.animation();
        float speed = flying ? animation.flyingSpeed() : animation.idleSpeed();
        float flapDegrees = flying ? animation.flyingFlapDegrees() : animation.idleFlapDegrees();
        float flap = Mth.m_14031_(ageInTicks * speed) * flapDegrees;
        int renderLight = CosmeticSelections.instance().fullBrightPreview ? LightTexture.f_173040_ : packedLight;

        poseStack.m_85836_();
        m_117386_().f_102810_.m_104299_(poseStack);
        poseStack.m_252880_(0.0F, -7.0F / 16.0F, 4.2F / 16.0F);
        poseStack.m_85841_(0.58F, 0.58F, 0.58F);

        renderWingSide(poseStack, bufferSource, renderLight, wing, false, animation.baseSpreadDegrees() + flap * animation.flapScale());
        renderWingSide(poseStack, bufferSource, renderLight, wing, true, animation.baseSpreadDegrees() + flap * animation.flapScale());

        poseStack.m_85849_();
    }

    private void renderWingSide(PoseStack poseStack, MultiBufferSource bufferSource, int renderLight, Wing wing, boolean mirrored, float flapAngle) {
        poseStack.m_85836_();
        poseStack.m_252880_(mirrored ? -2.4F / 16.0F : 2.4F / 16.0F, 0.0F, 0.0F);
        poseStack.m_252781_(Axis.f_252436_.m_252977_(mirrored ? flapAngle : -flapAngle));
        poseStack.m_252781_(Axis.f_252403_.m_252977_(mirrored ? -27.0F : 27.0F));
        if (mirrored) {
            poseStack.m_85841_(-1.0F, 1.0F, 1.0F);
        }
        wing.model().render(poseStack, bufferSource.m_6299_(RenderType.m_110458_(wing.texture())), renderLight);
        poseStack.m_85849_();
    }
}

package net.creeperhost.minetogethercommunity.cosmetic.cape;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.creeperhost.minetogethercommunity.cosmetic.CosmeticSelections;
import net.creeperhost.minetogethercommunity.cosmetic.PlayerCosmeticCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.util.Mth;

public class CapeLayer<T extends AbstractClientPlayer> extends RenderLayer<T, PlayerModel<T>> {

    public CapeLayer(RenderLayerParent<T, PlayerModel<T>> renderer) {
        super(renderer);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, T player,
                       float limbSwing, float limbSwingAmount, float partialTicks,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        String capeId;
        if (player == Minecraft.m_91087_().f_91074_) {
            // Local player - read from the singleton kept in sync with the GUI
            capeId = CosmeticSelections.instance().selectedCapeId;
        } else {
            // Remote player - look up the per-player cache (null = profile not fetched yet)
            CosmeticSelections cs = PlayerCosmeticCache.get(player.m_20148_());
            if (cs == null) return;
            capeId = cs.selectedCapeId;
        }
        if (capeId == null || capeId.isEmpty()) return;
        if (player.m_6844_(EquipmentSlot.CHEST).m_150930_(Items.f_42741_)) return;

        Cape cape = CapeRegistry.getLoaded(capeId);
        if (cape == null) return;

        poseStack.m_85836_();
        poseStack.m_252880_(0.0F, 0.0F, 0.125F);

        double d0 = Mth.m_14139_((double) partialTicks, player.f_36102_, player.f_36105_)
                  - Mth.m_14139_((double) partialTicks, player.f_19854_, player.m_20185_());
        double d1 = Mth.m_14139_((double) partialTicks, player.f_36103_, player.f_36106_)
                  - Mth.m_14139_((double) partialTicks, player.f_19855_, player.m_20186_());
        double d2 = Mth.m_14139_((double) partialTicks, player.f_36104_, player.f_36075_)
                  - Mth.m_14139_((double) partialTicks, player.f_19856_, player.m_20189_());

        float f = Mth.m_14189_(partialTicks, player.f_20884_, player.f_20883_);
        double d3 = (double) Mth.m_14031_(f * (float) (Math.PI / 180.0));
        double d4 = (double) (-Mth.m_14089_(f * (float) (Math.PI / 180.0)));

        float f1 = (float) d1 * 10.0F;
        f1 = Mth.m_14036_(f1, -6.0F, 32.0F);

        float f2 = (float) (d0 * d3 + d2 * d4) * 100.0F;
        f2 = Mth.m_14036_(f2, 0.0F, 150.0F);
        if (f2 < 0.0F) f2 = 0.0F;

        float f3 = (float) (d0 * d4 - d2 * d3) * 100.0F;
        f3 = Mth.m_14036_(f3, -20.0F, 20.0F);

        float f4 = Mth.m_14179_(partialTicks, player.f_36099_, player.f_36100_);
        f1 += Mth.m_14031_(Mth.m_14179_(partialTicks, player.f_19867_, player.f_19787_) * 6.0F) * 32.0F * f4;

        if (player.m_6047_()) {
            f1 += 25.0F;
        }

        poseStack.m_252781_(Axis.f_252529_.m_252977_(6.0F + f2 / 2.0F + f1));
        poseStack.m_252781_(Axis.f_252403_.m_252977_(f3 / 2.0F));
        poseStack.m_252781_(Axis.f_252436_.m_252977_(180.0F - f3 / 2.0F));

        VertexConsumer vertexConsumer = bufferSource.m_6299_(RenderType.m_110473_(cape.texture()));
        m_117386_().m_103411_(poseStack, vertexConsumer, packedLight, OverlayTexture.f_118083_);

        poseStack.m_85849_();
    }
}

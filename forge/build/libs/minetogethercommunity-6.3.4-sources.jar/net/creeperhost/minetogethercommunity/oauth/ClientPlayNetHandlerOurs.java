package net.creeperhost.minetogethercommunity.oauth;
import net.minecraft.ChatFormatting;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.*;

public class ClientPlayNetHandlerOurs implements ClientGamePacketListener {

    private final Connection networkManagerIn;

    public ClientPlayNetHandlerOurs(Connection networkManagerIn) {
        this.networkManagerIn = networkManagerIn;
    }

    @Override
    public void m_7026_(Component reason) {
        ServerAuthTest.disconnected(ChatFormatting.m_126649_(reason.getString()));
    }

    @Override
    public void m_6008_(ClientboundDisconnectPacket packetIn) {
        networkManagerIn.m_129507_(packetIn.m_132085_());
    }

    @Override
    public boolean m_6198_() {
        return this.networkManagerIn.m_129536_();
    }

    // NO-OP
    //@formatter:off
    @Override public void m_7231_(ClientboundKeepAlivePacket clientboundKeepAlivePacket) { }
    @Override public void m_141955_(ClientboundPingPacket clientboundPingPacket) { }
    @Override public void m_7413_(ClientboundCustomPayloadPacket clientboundCustomPayloadPacket) { }
    @Override public void m_6771_(ClientboundAddEntityPacket clientboundAddEntityPacket) { }
    @Override public void m_6482_(ClientboundAddPlayerPacket clientboundAddPlayerPacket) { }
    @Override public void m_7708_(ClientboundAddExperienceOrbPacket clientboundAddExperienceOrbPacket) { }
    @Override public void m_7957_(ClientboundSetObjectivePacket clientboundSetObjectivePacket) { }
    @Override public void m_7791_(ClientboundAnimatePacket clientboundAnimatePacket) { }
    @Override public void m_7271_(ClientboundAwardStatsPacket clientboundAwardStatsPacket) { }
    @Override public void m_8076_(ClientboundRecipePacket clientboundRecipePacket) { }
    @Override public void m_5943_(ClientboundBlockDestructionPacket clientboundBlockDestructionPacket) { }
    @Override public void m_8047_(ClientboundOpenSignEditorPacket clientboundOpenSignEditorPacket) { }
    @Override public void m_7545_(ClientboundBlockEntityDataPacket clientboundBlockEntityDataPacket) { }
    @Override public void m_7364_(ClientboundBlockEventPacket clientboundBlockEventPacket) { }
    @Override public void m_6773_(ClientboundBlockUpdatePacket clientboundBlockUpdatePacket) { }
    @Override public void m_213990_(ClientboundSystemChatPacket clientboundSystemChatPacket) { }
    @Override public void m_213629_(ClientboundPlayerChatPacket clientboundPlayerChatPacket) { }
    @Override public void m_241037_(ClientboundDeleteChatPacket clientboundDeleteChatPacket) { }
    @Override public void m_5771_(ClientboundSectionBlocksUpdatePacket clientboundSectionBlocksUpdatePacket) { }
    @Override public void m_7633_(ClientboundMapItemDataPacket clientboundMapItemDataPacket) { }
    @Override public void m_7776_(ClientboundContainerClosePacket clientboundContainerClosePacket) { }
    @Override public void m_6837_(ClientboundContainerSetContentPacket clientboundContainerSetContentPacket) { }
    @Override public void m_6905_(ClientboundHorseScreenOpenPacket clientboundHorseScreenOpenPacket) { }
    @Override public void m_7257_(ClientboundContainerSetDataPacket clientboundContainerSetDataPacket) { }
    @Override public void m_5735_(ClientboundContainerSetSlotPacket clientboundContainerSetSlotPacket) { }
    @Override public void m_7628_(ClientboundEntityEventPacket clientboundEntityEventPacket) { }
    @Override public void m_5599_(ClientboundSetEntityLinkPacket clientboundSetEntityLinkPacket) { }
    @Override public void m_6403_(ClientboundSetPassengersPacket clientboundSetPassengersPacket) { }
    @Override public void m_7345_(ClientboundExplodePacket clientboundExplodePacket) { }
    @Override public void m_7616_(ClientboundGameEventPacket clientboundGameEventPacket) { }
    @Override public void m_183388_(ClientboundLevelChunkWithLightPacket clientboundLevelChunkWithLightPacket) { }
    @Override public void m_5729_(ClientboundForgetLevelChunkPacket clientboundForgetLevelChunkPacket) { }
    @Override public void m_7704_(ClientboundLevelEventPacket clientboundLevelEventPacket) { }
    @Override public void m_5998_(ClientboundLoginPacket clientboundLoginPacket) { }
    @Override public void m_7865_(ClientboundMoveEntityPacket clientboundMoveEntityPacket) { }
    @Override public void m_5682_(ClientboundPlayerPositionPacket clientboundPlayerPositionPacket) { }
    @Override public void m_7406_(ClientboundLevelParticlesPacket clientboundLevelParticlesPacket) { }
    @Override public void m_5767_(ClientboundPlayerAbilitiesPacket clientboundPlayerAbilitiesPacket) { }
    @Override public void m_182047_(ClientboundRemoveEntitiesPacket clientboundRemoveEntitiesPacket) { }
    @Override public void m_6476_(ClientboundRemoveMobEffectPacket clientboundRemoveMobEffectPacket) { }
    @Override public void m_7992_(ClientboundRespawnPacket clientboundRespawnPacket) { }
    @Override public void m_6176_(ClientboundRotateHeadPacket clientboundRotateHeadPacket) { }
    @Override public void m_5612_(ClientboundSetCarriedItemPacket clientboundSetCarriedItemPacket) { }
    @Override public void m_5556_(ClientboundSetDisplayObjectivePacket clientboundSetDisplayObjectivePacket) { }
    @Override public void m_6455_(ClientboundSetEntityDataPacket clientboundSetEntityDataPacket) { }
    @Override public void m_8048_(ClientboundSetEntityMotionPacket clientboundSetEntityMotionPacket) { }
    @Override public void m_7277_(ClientboundSetEquipmentPacket clientboundSetEquipmentPacket) { }
    @Override public void m_6747_(ClientboundSetExperiencePacket clientboundSetExperiencePacket) { }
    @Override public void m_5547_(ClientboundSetHealthPacket clientboundSetHealthPacket) { }
    @Override public void m_5582_(ClientboundSetPlayerTeamPacket clientboundSetPlayerTeamPacket) { }
    @Override public void m_7519_(ClientboundSetScorePacket clientboundSetScorePacket) { }
    @Override public void m_6571_(ClientboundSetDefaultSpawnPositionPacket clientboundSetDefaultSpawnPositionPacket) { }
    @Override public void m_7885_(ClientboundSetTimePacket clientboundSetTimePacket) { }
    @Override public void m_8068_(ClientboundSoundPacket clientboundSoundPacket) { }
    @Override public void m_5863_(ClientboundSoundEntityPacket clientboundSoundEntityPacket) { }
    @Override public void m_8001_(ClientboundTakeItemEntityPacket clientboundTakeItemEntityPacket) { }
    @Override public void m_6435_(ClientboundTeleportEntityPacket clientboundTeleportEntityPacket) { }
    @Override public void m_7710_(ClientboundUpdateAttributesPacket clientboundUpdateAttributesPacket) { }
    @Override public void m_7915_(ClientboundUpdateMobEffectPacket clientboundUpdateMobEffectPacket) { }
    @Override public void m_5859_(ClientboundUpdateTagsPacket clientboundUpdateTagsPacket) { }
    @Override public void m_142234_(ClientboundPlayerCombatEndPacket clientboundPlayerCombatEndPacket) { }
    @Override public void m_142058_(ClientboundPlayerCombatEnterPacket clientboundPlayerCombatEnterPacket) { }
    @Override public void m_142747_(ClientboundPlayerCombatKillPacket clientboundPlayerCombatKillPacket) { }
    @Override public void m_6664_(ClientboundChangeDifficultyPacket clientboundChangeDifficultyPacket) { }
    @Override public void m_6447_(ClientboundSetCameraPacket clientboundSetCameraPacket) { }
    @Override public void m_142237_(ClientboundInitializeBorderPacket clientboundInitializeBorderPacket) { }
    @Override public void m_142686_(ClientboundSetBorderLerpSizePacket clientboundSetBorderLerpSizePacket) { }
    @Override public void m_142238_(ClientboundSetBorderSizePacket clientboundSetBorderSizePacket) { }
    @Override public void m_142056_(ClientboundSetBorderWarningDelayPacket clientboundSetBorderWarningDelayPacket) { }
    @Override public void m_142696_(ClientboundSetBorderWarningDistancePacket clientboundSetBorderWarningDistancePacket) { }
    @Override public void m_142612_(ClientboundSetBorderCenterPacket clientboundSetBorderCenterPacket) { }
    @Override public void m_6235_(ClientboundTabListPacket clientboundTabListPacket) { }
    @Override public void m_5587_(ClientboundResourcePackPacket clientboundResourcePackPacket) { }
    @Override public void m_7685_(ClientboundBossEventPacket clientboundBossEventPacket) { }
    @Override public void m_7701_(ClientboundCooldownPacket clientboundCooldownPacket) { }
    @Override public void m_7410_(ClientboundMoveVehiclePacket clientboundMoveVehiclePacket) { }
    @Override public void m_5498_(ClientboundUpdateAdvancementsPacket clientboundUpdateAdvancementsPacket) { }
    @Override public void m_7553_(ClientboundSelectAdvancementsTabPacket clientboundSelectAdvancementsTabPacket) { }
    @Override public void m_7339_(ClientboundPlaceGhostRecipePacket clientboundPlaceGhostRecipePacket) { }
    @Override public void m_7443_(ClientboundCommandsPacket clientboundCommandsPacket) { }
    @Override public void m_7183_(ClientboundStopSoundPacket clientboundStopSoundPacket) { }
    @Override public void m_7589_(ClientboundCommandSuggestionsPacket clientboundCommandSuggestionsPacket) { }
    @Override public void m_6327_(ClientboundUpdateRecipesPacket clientboundUpdateRecipesPacket) { }
    @Override public void m_7244_(ClientboundPlayerLookAtPacket clientboundPlayerLookAtPacket) { }
    @Override public void m_6148_(ClientboundTagQueryPacket clientboundTagQueryPacket) { }
    @Override public void m_183514_(ClientboundLightUpdatePacket clientboundLightUpdatePacket) { }
    @Override public void m_6503_(ClientboundOpenBookPacket clientboundOpenBookPacket) { }
    @Override public void m_5980_(ClientboundOpenScreenPacket clientboundOpenScreenPacket) { }
    @Override public void m_7330_(ClientboundMerchantOffersPacket clientboundMerchantOffersPacket) { }
    @Override public void m_7299_(ClientboundSetChunkCacheRadiusPacket clientboundSetChunkCacheRadiusPacket) { }
    @Override public void m_183623_(ClientboundSetSimulationDistancePacket clientboundSetSimulationDistancePacket) { }
    @Override public void m_8065_(ClientboundSetChunkCacheCenterPacket clientboundSetChunkCacheCenterPacket) { }
    @Override public void m_214108_(ClientboundBlockChangedAckPacket clientboundBlockChangedAckPacket) { }
    @Override public void m_142456_(ClientboundSetActionBarTextPacket clientboundSetActionBarTextPacket) { }
    @Override public void m_141913_(ClientboundSetSubtitleTextPacket clientboundSetSubtitleTextPacket) { }
    @Override public void m_142442_(ClientboundSetTitleTextPacket clientboundSetTitleTextPacket) { }
    @Override public void m_142185_(ClientboundSetTitlesAnimationPacket clientboundSetTitlesAnimationPacket) { }
    @Override public void m_142766_(ClientboundClearTitlesPacket clientboundClearTitlesPacket) { }
    @Override public void m_213672_(ClientboundServerDataPacket clientboundServerDataPacket) { }
    @Override public void m_240695_(ClientboundCustomChatCompletionsPacket clientboundCustomChatCompletionsPacket) { }
    @Override public void m_241155_(ClientboundUpdateEnabledFeaturesPacket clientboundUpdateEnabledFeaturesPacket) { }
    @Override public void m_264143_(ClientboundHurtAnimationPacket clientboundHurtAnimationPacket) { }
    @Override public void m_7039_(ClientboundDisguisedChatPacket clientboundDisguisedChatPacket) { }
    @Override public void m_274374_(ClientboundChunksBiomesPacket clientboundChunksBiomesPacket) { }
    @Override public void m_213565_(ClientboundPlayerInfoRemovePacket clientboundPlayerInfoRemovePacket) { }
    @Override public void m_214045_(ClientboundPlayerInfoUpdatePacket clientboundPlayerInfoUpdatePacket) { }
    @Override public void m_264308_(ClientboundBundlePacket clientboundBundlePacket) { }
    @Override public void m_269082_(ClientboundDamageEventPacket clientboundDamageEventPacket) { }
    //@formatter:on
}

package net.creeperhost.minetogethercommunity.compat.companion;

import dev.ftb.packcompanion.api.client.pause.AdditionalPauseProvider;
import dev.ftb.packcompanion.api.client.pause.AdditionalPauseTarget;
import dev.ftb.packcompanion.api.client.pause.ScreenHolder;
import dev.ftb.packcompanion.api.client.pause.ScreenWidgetCollection;
import net.creeperhost.minetogethercommunity.Constants;
import net.creeperhost.minetogethercommunity.chat.gui.FriendChatGui;
import net.creeperhost.minetogethercommunity.chat.gui.PublicChatGui;
import net.creeperhost.minetogethercommunity.config.LocalConfig;
import net.creeperhost.minetogethercommunity.connect.ConnectHandler;
import net.creeperhost.minetogethercommunity.connect.gui.GuiShareToFriends;
import net.creeperhost.minetogethercommunity.gui.SettingGui;
import net.creeperhost.minetogethercommunity.polylib.gui.IconButton;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;

public class PauseProvider implements AdditionalPauseProvider {
    @Override
    public ScreenWidgetCollection init(AdditionalPauseTarget target, ScreenHolder screen, int x, int y) {
        IntegratedServer integratedServer = Minecraft.m_91087_().m_91092_();
        var collection = ScreenWidgetCollection.create();

        int xOffset = 0;
        if (integratedServer != null) {
            boolean isConnectPublished = ConnectHandler.isPublished();
            Component buttonText = isConnectPublished ? Component.m_237115_("minetogether.connect.close") : Component.m_237115_("minetogether.connect.open");
            Button.OnPress action = button -> {
                if (isConnectPublished) {
                    ConnectHandler.unPublish();
                    Minecraft.m_91087_().m_91152_(new PauseScreen(true));
                } else {
                    Minecraft.m_91087_().m_91152_(new GuiShareToFriends.Screen(screen.unsafeScreenAccess()));
                }
            };

            xOffset += 98;
            collection.addRenderableWidget(Button.m_253074_(buttonText, action).m_252987_(x - xOffset, y, 98, 20).m_253136_());
        }

        xOffset += 22;

        var newSettingsBtn = new IconButton(x - xOffset, y, 3, Constants.WIDGETS_SHEET, e -> Minecraft.m_91087_().m_91152_(new SettingGui.Screen(screen.unsafeScreenAccess())));
        newSettingsBtn.m_257544_(Tooltip.m_257550_(Component.m_237115_("minetogether:gui.button.settings.info")));
        var newFriendChatBtn = new IconButton(x - xOffset - 22, y, 7, Constants.WIDGETS_SHEET, e -> Minecraft.m_91087_().m_91152_(new FriendChatGui.Screen(screen.unsafeScreenAccess())));
        newFriendChatBtn.m_257544_(Tooltip.m_257550_(Component.m_237115_("minetogether:gui.button.friends.info")));
        collection.addRenderableWidget(newSettingsBtn);
        collection.addRenderableWidget(newFriendChatBtn);

        if (LocalConfig.instance().chatEnabled) {
            var newPublicChatBtn = new IconButton(x - xOffset - 44, y, 1, Constants.WIDGETS_SHEET, e -> Minecraft.m_91087_().m_91152_(new PublicChatGui.Screen(screen.unsafeScreenAccess())));
            newPublicChatBtn.m_257544_(Tooltip.m_257550_(Component.m_237115_("minetogether:gui.button.global_chat.info")));
            collection.addRenderableWidget(newPublicChatBtn);
        }
        return collection;
    }
}

package net.creeperhost.minetogethercommunity.polylib.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * A simple {@link Button} implementation using an indexed icon
 * from the given texture sheet.
 * <p>
 * Expects 3 rows of at most 12 icons with the size of 20x20.<br>
 * Row 1, Active, non-hovered.<br>
 * Row 2, Active, hovered.<br>
 * Row 3, Inactive.<br>
 * <p>
 *
 * @author covers1624
 */
// TODO This can easily be expanded to support indexes higher than 12, and buttons with a size less than 20.
public class IconButton extends Button {

    private final ResourceLocation sheet;
    private final boolean single;
    private final int index;

    public IconButton(int x, int y, int index, ResourceLocation sheet, OnPress onPress) {
        super(x, y, 20, 20, Component.m_237119_(), onPress, Button.f_252438_);
        this.index = index;
        this.sheet = sheet;
        this.single = false;
    }

    public IconButton(int x, int y, int width, int height, ResourceLocation sheet, OnPress onPress) {
        super(x, y, width, height, Component.m_237119_(), onPress, Button.f_252438_);
        this.sheet = sheet;
        this.single = true;
        this.index = 0;
    }

    public void updateBounds(int x, int y, int width, int height) {
        this.m_252865_(x);
        this.m_253211_(y);
        this.m_93674_(width);
        this.f_93619_ = height;
    }

    @Override
    public void m_87963_(GuiGraphics graphics, int mx, int my, float partialTicks) {
        if (!f_93624_) return;

        if (single) {
            int fillColor = 0x80000000;
            if (f_93622_) {
                fillColor = 0x64202020;
            }
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            graphics.m_280509_(m_252754_(), m_252907_(), m_252754_() + f_93618_, m_252907_() + f_93619_, fillColor);
            graphics.m_280163_(sheet, m_252754_(), m_252907_(), 0, 0, f_93618_, f_93619_, f_93618_, f_93619_);
        } else {
            int yOffset = !f_93623_ ? 40 : f_93622_ ? 20 : 0;
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            graphics.m_280218_(sheet, m_252754_(), m_252907_(), index * 20, yOffset, f_93618_, f_93619_);
        }
    }
}

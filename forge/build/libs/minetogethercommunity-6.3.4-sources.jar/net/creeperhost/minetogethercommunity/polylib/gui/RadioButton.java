package net.creeperhost.minetogethercommunity.polylib.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import org.joml.Quaternionf;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Supplier;

/**
 * A simple button which remains 'active' once clicked, capable of being linked
 * to multiple other buttons to clear their 'active' state.
 * <p>
 * Created by covers1624 on 5/8/22.
 */
public class RadioButton extends Button {

    private final List<OnPress> actions = new LinkedList<>();

    private float textScale = 1.0F;
    private boolean verticalText = false;
    private int autoScaleMargins = -1;

    private Supplier<Boolean> selected = () -> false;
    private Runnable onRelease = () -> {
    };

    public RadioButton(int x, int y, int width, int height, Component text) {
        super(x, y, width, height, text, e -> {
        }, Button.f_252438_);
    }

    public void updateBounds(int x, int y, int width, int height) {
        this.m_252865_(x);
        this.m_253211_(y);
        this.m_93674_(width);
        this.f_93619_ = height; //Really??? There's a setter for everything except height?...
    }

    public RadioButton onRelease(Runnable onRelease) {
        this.onRelease = onRelease;
        return this;
    }

    /**
     * When enabled text will automatically be scaled to with the button bounds with the specified margins at each end.
     * This will only scale down, and only if required.
     * If text scale is set then that scale will be used as the "target" scale but we will scale down if required.
     *
     * @param autoScaleMargins Minimum required space at ether end of the text, -1 to disable auto-scale.
     * @return The same button.
     */
    public RadioButton withAutoScaleText(int autoScaleMargins) {
        this.autoScaleMargins = autoScaleMargins;
        return this;
    }

    /**
     * Sets the scale for the text.
     *
     * @param scale The text scale.
     * @return The same button.
     */
    public RadioButton withTextScale(float scale) {
        textScale = scale;
        return this;
    }

    /**
     * Sets if this button should render the text flipped.
     *
     * @return Render text vertically.
     */
    public RadioButton withVerticalText() {
        verticalText = true;
        return this;
    }

    /**
     * Add an action callback when this button is pressed.
     *
     * @param action The action callback.
     * @return The same button.
     */
    public RadioButton onPressed(OnPress action) {
        actions.add(action);
        return this;
    }

    /**
     * Use to control the "radio" part of the radio button.
     *
     * @param selected A suppler that returns true when the option this button represents is currently selected.
     */
    public RadioButton selectedSupplier(Supplier<Boolean> selected) {
        this.selected = selected;
        return this;
    }

    @Override
    public void m_5691_() {
        if (selected.get()) return;
        for (OnPress action : actions) {
            action.m_93750_(this);
        }
    }

    @Override
    public boolean m_6348_(double d, double e, int i) {
        onRelease.run();
        return super.m_6348_(d, e, i);
    }

    @Override
    public void m_87963_(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        int textColor = 0xFFFFFF;
        int fillColor = 0x64202020;
        if (f_93622_ || isPressed()) {
            textColor = 0xffffa0;
            fillColor = 0x80000000;
        }
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        graphics.m_280509_(m_252754_(), m_252907_(), m_252754_() + f_93618_, m_252907_() + f_93619_, fillColor);

        Font font = Minecraft.m_91087_().f_91062_;
        float scale = textScale;
        double lHeight = font.f_92710_ * scale;
        double lWidth = font.m_92852_(m_6035_()) * scale;

        int autoWidth = (verticalText ? f_93619_ : f_93618_) - (autoScaleMargins * 2);
        if (autoScaleMargins > -1 && lWidth > autoWidth) {
            scale *= autoWidth / lWidth;
            lHeight = font.f_92710_ * scale;
            lWidth = font.m_92852_(m_6035_()) * scale;
        }

        graphics.m_280168_().m_85836_();
        if (verticalText) {
            graphics.m_280168_().m_85837_(m_252754_() + lHeight + (f_93618_ / 2D) - (lHeight / 2D), m_252907_() + (f_93619_ / 2D) - (lWidth / 2D), 0);
            graphics.m_280168_().m_252781_(new Quaternionf().rotationXYZ(0F, 0F, 90F * 0.017453292F));
        } else {
            graphics.m_280168_().m_85837_(m_252754_() + (f_93618_ / 2D) - (lWidth / 2D), m_252907_() + (f_93619_ / 2D) - (lHeight / 2D), 0);
        }

        graphics.m_280168_().m_85841_(scale, scale, scale);

        graphics.m_280430_(font, m_6035_(), 0, 0, textColor);
        graphics.m_280168_().m_85849_();
    }

    public boolean isPressed() {
        return selected.get();
    }
}

package net.creeperhost.minetogethercommunity.polylib.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.joml.Quaternionf;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Simple slider control.
 * <p>
 * Created by brandon3055 on 06/29/2023
 */
public class SlideButton extends Button {

    private float textScale = 1.0F;
    private boolean verticalText = false;
    private int autoScaleMargins = -1;

    private Function<Double, Component> messageGetter;
    private Supplier<Double> valueGetter;
    private Consumer<Double> valueSetter;
    private double min = 0;
    private double max = 1;

    private boolean dragging = false;
    private double prevValue = 0;
    private double nextValue = 0;
    private int rangeLeft = 0;
    private int rangeRight = 0;
    private boolean applyOnRelease = false;

    private Runnable onRelease = () -> {};
    private Supplier<Boolean> enabled = null;

    public SlideButton(int x, int y, int width, int height) {
        this(x, y, width, height, Component.m_237119_());
    }

    public SlideButton(int x, int y, int width, int height, Component message) {
        super(x, y, width, height, message, e -> {}, Button.f_252438_);
    }

    public SlideButton setEnabled(Supplier<Boolean> enabled) {
        this.enabled = enabled;
        return this;
    }

    public boolean isEnabled() {
        return enabled == null || enabled.get();
    }

    @Override
    public Component m_6035_() {
        return messageGetter == null ? super.m_6035_() : messageGetter.apply(nextValue);
    }

    public SlideButton onRelease(Runnable onRelease) {
        this.onRelease = onRelease;
        return this;
    }

    public SlideButton setApplyOnRelease(boolean applyOnRelease) {
        this.applyOnRelease = applyOnRelease;
        return this;
    }

    public SlideButton setDynamicMessage(Function<Double, Component> messageGetter) {
        this.messageGetter = messageGetter;
        return this;
    }

    public SlideButton setDynamicMessage(Supplier<Component> messageGetter) {
        this.messageGetter = aDouble -> messageGetter.get();
        return this;
    }

    public SlideButton bindValue(Supplier<Double> valueGetter, Consumer<Double> valueSetter) {
        this.valueGetter = valueGetter;
        this.valueSetter = valueSetter;
        this.nextValue = valueGetter.get();
        return this;
    }

    public SlideButton setRange(double min, double max) {
        this.max = max;
        this.min = min;
        return this;
    }

    public void updateBounds(int x, int y, int width, int height) {
        this.m_252865_(x);
        this.m_253211_(y);
        this.m_93674_(width);
        this.f_93619_ = height; //Really??? There's a setter for everything except height?...
    }

    /**
     * When enabled text will automatically be scaled to with the button bounds with the specified margins at each end.
     * This will only scale down, and only if required.
     * If text scale is set then that scale will be used as the "target" scale but we will scale down if required.
     *
     * @param autoScaleMargins Minimum required space at ether end of the text, -1 to disable auto-scale.
     * @return The same button.
     */
    public SlideButton withAutoScaleText(int autoScaleMargins) {
        this.autoScaleMargins = autoScaleMargins;
        return this;
    }

    /**
     * Sets the scale for the text.
     *
     * @param scale The text scale.
     * @return The same button.
     */
    public SlideButton withTextScale(float scale) {
        textScale = scale;
        return this;
    }

// TODO Will get this working if we need it.
//    /**
//     * Sets if this button should render the text flipped.
//     *
//     * @return Render text vertically.
//     */
//    public SlideButton withVerticalText() {
//        verticalText = true;
//        return this;
//    }

    @Override
    public void m_5716_(double mouseX, double mouseY) {
        if (!isEnabled()) return;
        dragging = true;
        int endOffset = f_93618_ / 20;
        rangeLeft = m_252754_() + endOffset;
        rangeRight = m_252754_() + f_93618_ - endOffset;
        prevValue = valueGetter.get();
        updateDrag(mouseX);
    }

    @Override
    public boolean m_7979_(double mouseX, double mouseY, int i, double f, double g) {
        if (!dragging) return false;
        if (mouseY < m_252907_() - 50 || mouseY > m_252907_() + f_93619_ + 50) {
            valueSetter.accept(prevValue);
            nextValue = prevValue;
            return true;
        }

        updateDrag(mouseX);

        return true;
    }

    @Override
    public boolean m_6348_(double d, double e, int i) {
        if (dragging) {
            dragging = false;
            onRelease.run();
            if (applyOnRelease) {
                valueSetter.accept(nextValue);
            }
        }

        return super.m_6348_(d, e, i);
    }

    private void updateDrag(double mouseX) {
        double range = max - min;
        mouseX -= rangeLeft;
        double pos = mouseX / (rangeRight - rangeLeft);
        nextValue = Mth.m_14008_(min + (pos * range), min, max);
        if (!applyOnRelease) {
            valueSetter.accept(nextValue);
        }
    }

    @Override
    public void m_87963_(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        if (!isEnabled()) return;
        int textColor = 0xFFFFFF;
        int fillColor = 0x80000000;
        int sliderColor = 0x64808080;

        if (f_93622_ || dragging) {
            sliderColor = 0xFFA0A0A0;
        }

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        graphics.m_280509_(m_252754_(), m_252907_(), m_252754_() + f_93618_, m_252907_() + f_93619_, fillColor);

        int slideWidth = f_93618_ / 10;
        double pos = (nextValue - min) / (max - min);
        int slidePos = (int) ((f_93618_ - slideWidth) * pos);

        graphics.m_280509_(m_252754_() + slidePos, m_252907_(), m_252754_() + slidePos + slideWidth, m_252907_() + f_93619_, sliderColor);

        Font font = Minecraft.m_91087_().f_91062_;
        float scale = textScale;
        double lHeight = font.f_92710_ * scale;
        double lWidth = font.m_92852_(m_6035_()) * scale;

        int autoWidth = (verticalText ? f_93619_ : f_93618_) - (autoScaleMargins * 2);
        if (autoScaleMargins > -1 && lWidth > autoWidth) {
            scale *= autoWidth / lWidth;
            lHeight = font.f_92710_ * scale;
            lWidth = font.m_92852_(m_6035_()) * scale;
        }

        graphics.m_280168_().m_85836_();
        if (verticalText) {
            graphics.m_280168_().m_85837_(m_252754_() + lHeight + (f_93618_ / 2D) - (lHeight / 2D), m_252907_() + (f_93619_ / 2D) - (lWidth / 2D), 0);
            graphics.m_280168_().m_252781_(new Quaternionf().rotationXYZ(0F, 0F, 90F * 0.017453292F));
        } else {
            graphics.m_280168_().m_85837_(m_252754_() + (f_93618_ / 2D) - (lWidth / 2D), m_252907_() + (f_93619_ / 2D) - (lHeight / 2D), 0);
        }

        graphics.m_280168_().m_85841_(scale, scale, 1);

        graphics.m_280430_(font, m_6035_(), 0, 0, textColor);
        graphics.m_280262_();

        graphics.m_280168_().m_85849_();
    }
}

package net.creeperhost.minetogethercommunity.orderform.elements;

import net.creeperhost.minetogethercommunity.chat.gui.MTStyle;
import net.creeperhost.minetogethercommunity.gui.dialogs.ItemSelectDialog;
import net.creeperhost.minetogethercommunity.orderform.OrderGui;
import net.creeperhost.minetogethercommunity.orderform.WorldUploader;
import net.creeperhost.polylib.client.modulargui.ModularGui;
import net.creeperhost.polylib.client.modulargui.elements.GuiDialog;
import net.creeperhost.polylib.client.modulargui.elements.GuiElement;
import net.creeperhost.polylib.client.modulargui.elements.GuiText;
import net.creeperhost.polylib.client.modulargui.lib.geometry.Align;
import net.creeperhost.polylib.client.modulargui.lib.geometry.GuiParent;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.StringUtil;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.level.storage.LevelStorageException;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.storage.LevelSummary;
import org.jetbrains.annotations.NotNull;

import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static net.creeperhost.polylib.client.modulargui.lib.geometry.Constraint.*;
import static net.creeperhost.polylib.client.modulargui.lib.geometry.GeoParam.*;
import static net.minecraft.ChatFormatting.*;

/**
 * Created by brandon3055 on 28/06/2024
 */
public class WorldElement extends GuiElement<WorldElement> {

    private final OrderGui gui;

    public String worldName = "";
    public WorldUploader worldUploader = null;

    public WorldElement(@NotNull GuiParent<?> parent, OrderGui gui) {
        super(parent);
        this.gui = gui;

        GuiElement<?> lastElement = new GuiText(this, Component.m_237115_("minetogether:gui.order.world").m_130944_(ChatFormatting.UNDERLINE, ChatFormatting.GOLD))
                .setAlignment(Align.LEFT)
                .constrain(TOP, match(get(TOP)))
                .constrain(LEFT, match(get(LEFT)))
                .constrain(RIGHT, match(get(RIGHT)))
                .constrain(HEIGHT, literal(8));

        Component worldInfo = Component.m_237115_("minetogether:gui.order.world.info").m_130940_(ChatFormatting.GRAY);
        lastElement = new GuiText(this, worldInfo)
                .setWrap(true)
                .setAlignment(Align.LEFT)
                .constrain(TOP, relative(lastElement.get(BOTTOM), 3))
                .constrain(LEFT, match(get(LEFT)))
                .constrain(RIGHT, match(get(RIGHT)));
        lastElement.constrain(HEIGHT, dynamic(() -> (double) this.font().m_239133_(worldInfo, (int) xMax() - (int) xMin())));

        List<LevelSummary> levels = loadLevels(this.mc());
        if (levels.isEmpty()) {
            Component noWorlds = Component.m_237115_("minetogether:gui.order.world.no_worlds").m_130940_(RED);
            lastElement = new GuiText(this, noWorlds)
                    .setWrap(true)
                    .setAlignment(Align.LEFT)
                    .constrain(TOP, relative(lastElement.get(BOTTOM), 3))
                    .constrain(LEFT, match(get(LEFT)))
                    .constrain(RIGHT, match(get(RIGHT)));
            lastElement.constrain(HEIGHT, dynamic(() -> (double) this.font().m_239133_(noWorlds, (int) xMax() - (int) xMin())));
        } else {
            lastElement = MTStyle.Flat.button(this, () -> worldUploader != null && worldUploader.errored() ? Component.m_237113_(worldUploader.getError()).m_130940_(RED) : Component.m_237115_("minetogether:gui.order.world.select"))
                    .setDisabled(() -> worldUploader != null || !StringUtil.m_14408_(gui.order.worldUrl))
                    .onPress(() -> new ItemSelectDialog<>(this.getModularGui().getRoot(), Component.m_237115_("minetogether:gui.order.world.select"), levels, levels.get(0), e -> Component.m_237119_().m_7220_(Component.m_237113_(e.m_78361_()).m_130940_(GREEN)).m_130946_("\n").m_7220_(e.m_78376_()).m_130940_(GRAY))
                            .setCloseOnOutsideClick(true)
                            .setOnItemSelected(selected -> {
                                Path worldFolder = this.mc().m_91392_().m_78257_().resolve(selected.m_78358_());
                                confirmStartUpload(worldFolder, selected.m_78361_());
                            })
                    )
                    .constrain(TOP, relative(lastElement.get(BOTTOM), 3))
                    .constrain(LEFT, match(get(LEFT)))
                    .constrain(RIGHT, match(get(RIGHT)))
                    .constrain(HEIGHT, literal(12));

            //Right Cancel/Remove button
            lastElement = MTStyle.Flat.buttonCaution(this, this::cancelWorldText)
                    .setDisabled(() -> worldUploader == null && StringUtil.m_14408_(gui.order.worldUrl))
                    .onPress(this::cancelWorldAction)
                    .constrain(TOP, relative(lastElement.get(BOTTOM), 3))
                    .constrain(WIDTH, literal(60))
                    .constrain(RIGHT, match(get(RIGHT)))
                    .constrain(HEIGHT, literal(12));

            //Left Progress/Copy/Retry button
            MTStyle.Flat.button(this, this::worldBtnLeft)
                    .setDisabled(() -> !(worldUploader != null && worldUploader.errored()))
                    .onPress(this::worldBtnLeftAction)
                    .constrain(TOP, match(lastElement.get(TOP)))
                    .constrain(LEFT, match(get(LEFT)))
                    .constrain(RIGHT, relative(lastElement.get(LEFT), -2))
                    .constrain(HEIGHT, literal(12));
        }

        constrain(BOTTOM, match(lastElement.get(BOTTOM)));
//        Constraints.bind(new GuiRectangle(this).border(0xFFFF0000), this);
    }

    private Component worldBtnLeft() {
        if (!StringUtil.m_14408_(gui.order.worldUrl)) {
            return Component.m_237110_("minetogether:gui.order.world.upload_complete", worldName).m_130940_(GREEN);
        } else if (worldUploader != null) {
            if (worldUploader.errored()) {
                return Component.m_237115_("minetogether:gui.order.world.retry");
            }
            return worldUploader.getStatus();
        }
        return Component.m_237119_();
    }

    private void worldBtnLeftAction() {
        if (!StringUtil.m_14408_(gui.order.worldUrl)) {
            Minecraft.m_91087_().f_91068_.m_90911_(gui.order.worldUrl);
        } else if (worldUploader != null && worldUploader.errored()) {
            worldUploader.start();
        }
    }

    private Component cancelWorldText() {
        if (!StringUtil.m_14408_(gui.order.worldUrl)) {
            return Component.m_237115_("minetogether:gui.order.world.remove");
        } else if (worldUploader != null) {
            return Component.m_237115_("gui.cancel");
        }
        return Component.m_237119_();
    }

    private void cancelWorldAction() {
        if (!StringUtil.m_14408_(gui.order.worldUrl)) {
            gui.order.worldUrl = "";
        } else if (worldUploader != null) {
            worldUploader.cancel();
            worldUploader = null;
        }
    }

    private List<LevelSummary> loadLevels(Minecraft minecraft) {
        LevelStorageSource.LevelCandidates candidates;
        try {
            candidates = minecraft.m_91392_().m_230833_();
        } catch (LevelStorageException e) {
            OrderGui.LOGGER.error("Couldn't load level list", e);
            return Collections.emptyList();
        }

        if (candidates.m_230843_()) {
            return Collections.emptyList();
        } else {
            try {
                return minecraft.m_91392_()
                        .m_230813_(candidates)
                        .exceptionally((e) -> {
                            OrderGui.LOGGER.error("Couldn't load level list", e);
                            return List.of();
                        })
                        .get();
            } catch (InterruptedException | ExecutionException e) {
                OrderGui.LOGGER.error("Couldn't load level list", e);
                return Collections.emptyList();
            }
        }
    }

    private void confirmStartUpload(Path worldFolder, String levelName) {
        GuiDialog.optionsDialog(this, Component.m_237110_("minetogether:gui.order.confirm_upload",
                        Component.m_237113_(levelName).m_130940_(GOLD)).m_130940_(BLUE),
                Component.m_237115_("minetogether:gui.order.confirm_upload.info").m_130940_(GRAY),
                250,
                GuiDialog.primary(Component.m_237115_("minetogether:gui.order.world.upload"), () -> startWorldUpload(worldFolder, levelName)),
                GuiDialog.caution(Component.m_237115_("gui.cancel"), () -> {})
        );
    }

    private void startWorldUpload(Path worldFolder, String levelName) {
        if (worldUploader != null) return;
        worldName = levelName;
        worldUploader = new WorldUploader(worldFolder);
        worldUploader.start();
    }

    public void uploadCurrentWorld(ModularGui gui) {
        IntegratedServer server = gui.mc().m_91092_();
        if (server == null) return;
        LevelStorageSource.LevelStorageAccess storage = server.f_129744_;
        Path levelPath = storage.m_78283_(LevelResource.f_78182_).toAbsolutePath();
        confirmStartUpload(levelPath, server.m_129910_().m_5462_());
    }

//    private void uploadCurrentWorld(ModularGui gui) {

//        world.startWorldUpload();
//
//
//    }
}

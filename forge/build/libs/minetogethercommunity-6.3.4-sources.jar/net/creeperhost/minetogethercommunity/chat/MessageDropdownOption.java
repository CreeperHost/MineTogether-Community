package net.creeperhost.minetogethercommunity.chat;

import net.minecraft.network.chat.Component;

/**
 * Created by covers1624 on 5/10/22.
 */
public enum MessageDropdownOption {
    MUTE(Component.m_237115_("minetogether:button.mute")),
    ADD_FRIEND(Component.m_237115_("minetogether:button.add_friend")),
    MENTION(Component.m_237115_("minetogether:button.mention"));

    public static final MessageDropdownOption[] VALUES = values();

    private final Component title;

    MessageDropdownOption(Component title) {
        this.title = title;
    }

    public Component getTitle(boolean isOpen) {
        return title;
    }
}

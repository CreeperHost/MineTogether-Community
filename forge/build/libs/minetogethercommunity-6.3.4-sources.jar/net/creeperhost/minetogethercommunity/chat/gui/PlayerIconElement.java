package net.creeperhost.minetogethercommunity.chat.gui;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.creeperhost.minetogethercommunity.gui.MTTextures;
import net.creeperhost.polylib.client.modulargui.elements.GuiElement;
import net.creeperhost.polylib.client.modulargui.lib.BackgroundRender;
import net.creeperhost.polylib.client.modulargui.lib.GuiRender;
import net.creeperhost.polylib.client.modulargui.lib.geometry.GuiParent;
import net.creeperhost.polylib.client.modulargui.sprite.Material;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

/**
 * Created by brandon3055 on 28/10/2023
 */
public class PlayerIconElement extends GuiElement<PlayerIconElement> implements BackgroundRender {
    @Nullable
    private RenderType skinType;
    public boolean textureFail = false;
    @Nullable
    private GameProfile profile;
    private Material fallback = MTTextures.get("player_offline");

    /**
     * @param parent parent {@link GuiParent}.
     */
    public PlayerIconElement(@NotNull GuiParent<?> parent, @Nullable GameProfile profile) {
        super(parent);
        this.profile = profile;
    }

    public void setProfile(GameProfile profile) {
        this.profile = profile;
        skinType = null;
        textureFail = false;
    }

    @Override
    public void renderBehind(GuiRender render, double mouseX, double mouseY, float partialTicks) {
        if (skinType == null && profile != null && !textureFail) {
            updateGameProfile();
        }

        if (skinType != null) {
            draw(render);
        } else {
            render.texRect(fallback, getRectangle());
        }
    }

    public void draw(GuiRender render) {
        float texMin = 8/64F;
        float texMax = 16/64F;

        VertexConsumer buffer = render.buffers().m_6299_(skinType);
        Matrix4f mat = render.pose().m_85850_().m_252922_();
        buffer.m_252986_(mat, (float) xMax(), (float) yMax(), 0).m_7421_(texMax, texMax).m_5752_();  //R-B
        buffer.m_252986_(mat, (float) xMax(), (float) yMin(), 0).m_7421_(texMax, texMin).m_5752_();  //R-T
        buffer.m_252986_(mat, (float) xMin(), (float) yMin(), 0).m_7421_(texMin, texMin).m_5752_();  //L-T
        buffer.m_252986_(mat, (float) xMin(), (float) yMax(), 0).m_7421_(texMin, texMax).m_5752_();  //L-B
        render.flush();
    }


    private void updateGameProfile() {
        if (profile == null) return;

        if (!profile.getProperties().containsKey("textures")) {
            GameProfile filled = mc().m_91108_().fillProfileProperties(profile, true);
            if (filled == null) {
                textureFail = true;
                return;
            }
            profile = filled;
        }

        ResourceLocation texture = mc().m_91109_().m_240306_(profile);
        if (!texture.equals(DefaultPlayerSkin.m_118627_(profile.getId()))) {
            skinType = GuiRender.texType(texture);
        } else {
            textureFail = true;
        }
    }
}

package net.creeperhost.minetogethercommunity.chat;

import dev.architectury.hooks.client.screen.ScreenHooks;
import dev.architectury.platform.Platform;
import net.creeperhost.minetogether.lib.chat.ChatState;
import net.creeperhost.minetogether.lib.chat.MutedUserList;
import net.creeperhost.minetogether.lib.chat.irc.IrcChannel;
import net.creeperhost.minetogether.lib.chat.irc.IrcClient;
import net.creeperhost.minetogether.lib.chat.profile.Profile;
import net.creeperhost.minetogether.lib.chat.profile.ProfileManager;
import net.creeperhost.minetogethercommunity.Constants;
import net.creeperhost.minetogethercommunity.MineTogether;
import net.creeperhost.minetogethercommunity.chat.gui.FriendChatGui;
import net.creeperhost.minetogethercommunity.chat.gui.PublicChatGui;
import net.creeperhost.minetogethercommunity.chat.ingame.MTChatComponent;
import net.creeperhost.minetogethercommunity.config.Config;
import net.creeperhost.minetogethercommunity.config.LocalConfig;
import net.creeperhost.minetogethercommunity.gui.SettingGui;
import net.creeperhost.minetogethercommunity.polylib.gui.IconButton;
import net.creeperhost.minetogethercommunity.util.ModPackInfo;
import net.creeperhost.polylib.client.modulargui.ModularGuiScreen;
import net.creeperhost.polylib.client.toast.SimpleToast;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.toasts.Toast;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;

/**
 * @author covers1624
 */
public class MineTogetherChat {

    private static final Logger LOGGER = LogManager.getLogger();

    public static final ChatAuthImpl CHAT_AUTH = new ChatAuthImpl(Minecraft.m_91087_());
    private static final MutedUserList MUTED_USER_LIST = new MutedUserList(
            Platform.getGameFolder().resolve("local/minetogether/mutedusers.json")
    );

    public static ChatState CHAT_STATE = new ChatState(MineTogether.API, CHAT_AUTH, MUTED_USER_LIST, () -> ModPackInfo.getInfo().realName, false);

    public static ChatComponent vanillaChat;
    public static MTChatComponent publicChat;
    public static MTChatComponent groupChat;
    private static boolean hasHitLoadingScreen = false;

    public static void init() {
        CHAT_STATE.logChatToConsole = Config.instance().logChatToConsole | Config.instance().debugMode;

        if (Config.instance().debugMode) {
            System.setProperty("net.covers1624.pircbot.logging.info", "INFO");
            System.setProperty("net.covers1624.pircbot.logging.debug", "INFO");
            System.setProperty("net.covers1624.pircbot.logging.very_verbose", "true");
        }

        ChatStatistics.pollStats();
    }

    public static void initChat(Gui gui) {
        Minecraft mc = Minecraft.m_91087_();
        vanillaChat = gui.f_92988_;
        publicChat = new MTChatComponent(ChatTarget.PUBLIC, mc);
        groupChat = new MTChatComponent(ChatTarget.GROUP, mc);
        if (LocalConfig.instance().chatEnabled) {
            CHAT_STATE.ircClient.start();
        }
        CHAT_STATE.ircClient.addChannelListener(new IrcClient.ChannelListener() {
            @Override
            public void channelJoin(IrcChannel channel) {
                if (CHAT_STATE.ircClient.getPrimaryChannel() == null) return;
                if (channel == CHAT_STATE.ircClient.getPrimaryChannel()) {
                    publicChat.attach(channel);

                    Screen screen = Minecraft.m_91087_().f_91080_;

                    // If we have the ChatScreen open. Attach to main chat.
                    if (screen instanceof ModularGuiScreen mgui && mgui.getModularGui().getProvider() instanceof PublicChatGui chat) {
                        chat.chatMonitor.attach(channel);
                    }
                }
                ProfileManager.PrivateGroup group = CHAT_STATE.profileManager.getPrivateGroup();
                if (group != null && group.channelName.equals(channel.getName())) {
                    groupChat.attach(channel);
                }
            }

            @Override
            public void channelLeave(IrcChannel channel) {

            }
        });

        CHAT_STATE.profileManager.addListener(mc, (m, e) -> m.m_18707_(() -> {
            if (e.type == ProfileManager.EventType.FRIEND_REQUEST_ADDED) {
                ProfileManager.FriendRequest fr = (ProfileManager.FriendRequest) e.data;
                simpleToast(Component.m_237110_("minetogether:toast.fiend_request_received", displayName(fr.user)));
            } else if (e.type == ProfileManager.EventType.FRIEND_REQUEST_ACCEPTED) {
                Profile fr = (Profile) e.data;
                simpleToast(Component.m_237110_("minetogether:toast.fiend_request_accepted", displayName(fr)));
            } else if (e.type == ProfileManager.EventType.FRIEND_ONLINE && LocalConfig.instance().friendNotifications) {
                Profile fr = (Profile) e.data;
                simpleToast(Component.m_237110_("minetogether:toast.user_online", displayName(fr)));
            } else if (e.type == ProfileManager.EventType.FRIEND_OFFLINE && LocalConfig.instance().friendNotifications) {
                Profile fr = (Profile) e.data;
                simpleToast(Component.m_237110_("minetogether:toast.user_offline", displayName(fr)));
            } else if (e.type == ProfileManager.EventType.GROUP_INVITE_RECEIVED) {
                ProfileManager.PrivateGroup group = (ProfileManager.PrivateGroup) e.data;
                if (group != null && group.ownerHash != null) {
                    Profile sender = CHAT_STATE.profileManager.lookupProfile(group.ownerHash);
                    simpleToast(Component.m_237110_("minetogether:toast.group_invite_received", displayName(sender)));
                }
            } else if (e.type == ProfileManager.EventType.LEFT_GROUP) {
                if (getTarget() == ChatTarget.GROUP) {
                    setTarget(ChatTarget.VANILLA);//Switch to vanilla rather than public to avoid situations where a user starts sending private messages without realizing they have left the group.
                }
                simpleToast(Component.m_237115_("minetogether:toast.left_group"), Component.m_237115_("minetogether:toast.left_group." + e.data));
            }
        }));

        // If the user has an account. Set firstConnect just incase.
        String lowerHash = CHAT_AUTH.getHash().toLowerCase(Locale.ROOT);
        if (!LocalConfig.instance().firstConnect.contains(lowerHash) && CHAT_STATE.profileManager.getOwnProfile().hasAccount()) {
            LocalConfig.instance().firstConnect.add(lowerHash);
            LocalConfig.save();
        }
    }

    public static void simpleToast(Component toastText) {
        addToast(new SimpleToast(
                toastText,
                Component.m_237119_(),
                Constants.MINETOGETHER_LOGO_SOLID
        ));
    }

    public static void simpleToast(Component toastTitle, Component toastText) {
        addToast(new SimpleToast(
                toastTitle,
                toastText,
                Constants.MINETOGETHER_LOGO_SOLID
        ));
    }

    private static void addToast(Toast toast) {
        if (hasHitLoadingScreen) {
            Minecraft.m_91087_().m_91300_().m_94922_(toast);
        } else {
            // YEET, too bad.
        }
    }

    public static Profile getOurProfile() {
        return CHAT_STATE.profileManager.getOwnProfile();
    }

    public static void onScreenPostInit(Screen screen) {
        if (screen instanceof TitleScreen) {
            if (!hasHitLoadingScreen) {
                hasHitLoadingScreen = true;
            }
            if (LocalConfig.instance().mainMenuButtons) {
                addMenuButtons(screen);
            }
        } else if (screen instanceof PauseScreen) {
            if (Config.instance().pauseScreenButtons) {
                addMenuButtons(screen);
            }
        }
    }

    private static void addMenuButtons(Screen screen) {
        int buttonPos = 4;
        IconButton settings = new IconButton(screen.f_96543_ - (buttonPos += 21), 5, 3, Constants.WIDGETS_SHEET, e -> Minecraft.m_91087_().m_91152_(new SettingGui.Screen(screen)));
        settings.m_257544_(Tooltip.m_257550_(Component.m_237115_("minetogether:gui.button.settings.info")));
        ScreenHooks.addRenderableWidget(screen, settings);

        IconButton friendChat = new IconButton(screen.f_96543_ - (buttonPos += 21), 5, 7, Constants.WIDGETS_SHEET, e -> Minecraft.m_91087_().m_91152_(new FriendChatGui.Screen(screen)));
        friendChat.m_257544_(Tooltip.m_257550_(Component.m_237115_("minetogether:gui.button.friends.info")));
        ScreenHooks.addRenderableWidget(screen, friendChat);

        if (LocalConfig.instance().chatEnabled) {
            IconButton publicChat = new IconButton(screen.f_96543_ - (buttonPos += 21), 5, 1, Constants.WIDGETS_SHEET, e -> Minecraft.m_91087_().m_91152_(new PublicChatGui.Screen(screen)));
            publicChat.m_257544_(Tooltip.m_257550_(Component.m_237115_("minetogether:gui.button.global_chat.info")));
            ScreenHooks.addRenderableWidget(screen, publicChat);
        }
    }

    public static boolean isNewUser() {
        if (MineTogetherChat.getOurProfile().hasAccount()) return false;

        return !LocalConfig.instance().firstConnect.contains(CHAT_AUTH.getHash().toLowerCase(Locale.ROOT));
    }

    public static void setNewUserResponded() {
        LocalConfig.instance().firstConnect.add(CHAT_AUTH.getHash().toLowerCase(Locale.ROOT));
        LocalConfig.save();
    }

    public static void disableChat() {
        CHAT_STATE.ircClient.stop();
    }

    public static void enableChat() {
        CHAT_STATE.ircClient.start();
    }

    public static void setTarget(ChatTarget target) {
        LocalConfig.instance().selectedTab = target;
        LocalConfig.save();
    }

    public static ChatTarget getTarget() {
        return LocalConfig.instance().chatEnabled ? LocalConfig.instance().selectedTab : ChatTarget.VANILLA;
    }

    public static String displayName(@Nullable Profile profile) {
        return profile == null ? "" : profile.isFriend() && profile.hasFriendName() ? profile.getFriendName() : profile.getDisplayName();
    }
}

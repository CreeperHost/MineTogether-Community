package net.creeperhost.minetogethercommunity.chat.ingame;

import net.covers1624.quack.collection.FastStream;
import net.creeperhost.minetogethercommunity.chat.ChatTarget;
import net.creeperhost.minetogethercommunity.chat.DisplayableMessage;
import net.creeperhost.minetogethercommunity.chat.MineTogetherChat;
import net.creeperhost.minetogether.lib.chat.irc.IrcChannel;
import net.creeperhost.minetogether.lib.chat.message.Message;
import net.creeperhost.minetogether.lib.chat.message.MessageComponent;
import net.creeperhost.minetogethercommunity.util.MessageFormatter;
import net.minecraft.client.GuiMessage;
import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

/**
 * Created by covers1624 on 20/7/22.
 */
public class MTChatComponent extends ChatComponent {

    private static final Logger LOGGER = LogManager.getLogger();

    // TODO tweak this.
    private static final int MAX_MESSAGE_HISTORY = 150;

    private final ChatTarget target;
    private final Minecraft minecraft;

    // Flag to override explicitly delegating to vanilla, set in specific cases.
    private boolean internalUpdate = false;

    private final List<InGameDisplayableMessage> changedMessages = new LinkedList<>();
    private final LinkedList<Message> pendingMessages = new LinkedList<>();
    private final List<InGameDisplayableMessage> processedMessages = new ArrayList<>();
    @Nullable
    private IrcChannel channel;
    @Nullable
    private IrcChannel.ChatListener listener;

    @Nullable
    private Message clickedMessage;

    public MTChatComponent(ChatTarget target, Minecraft minecraft) {
        super(minecraft);
        this.target = target;
        this.minecraft = minecraft;
        assert target != ChatTarget.VANILLA : "MTChatComponent doesn't work this way";
    }

    public void attach(IrcChannel channel) {
        if (this.channel == channel) return;

        if (this.channel != null) {
            assert listener != null;
            this.channel.removeListener(listener);
            listener = null;
        }

        synchronized (pendingMessages) {
            pendingMessages.clear();
        }
        synchronized (processedMessages) {
            for (InGameDisplayableMessage message : processedMessages) {
                message.onDead();
            }
            processedMessages.clear();
        }
        f_93761_.clear();
        m_93810_();

        this.channel = channel;
        synchronized (pendingMessages) {
            pendingMessages.addAll(channel.getMessages());
        }
        listener = channel.addListener(message -> {
            synchronized (pendingMessages) {
                pendingMessages.add(message);
            }
        });
    }

    @Override
    public void m_246602_() {
        super.m_246602_();
        // Fallback to force bind the channel if it is null.
        if (channel == null && target == ChatTarget.PUBLIC) {
            IrcChannel channel = MineTogetherChat.CHAT_STATE.ircClient.getPrimaryChannel();
            if (channel != null) {
                attach(channel);
            }
        }
    }

    @Override
    public void m_280165_(GuiGraphics graphics, int i, int j, int k) {
        if (!pendingMessages.isEmpty()) {
            internalUpdate = true;
            synchronized (pendingMessages) {
                for (Message pendingMessage : pendingMessages) {
                    addMessage(pendingMessage);
                }
                pendingMessages.clear();
            }
            internalUpdate = false;
        }
        if (!changedMessages.isEmpty()) {
            synchronized (changedMessages) {
                for (InGameDisplayableMessage changedMessage : changedMessages) {
                    changedMessage.reformat();
                }
                changedMessages.clear();
            }
        }
        super.m_280165_(graphics, i, j, k);
    }

    @Override
    public void m_93769_() {
        // If we are the target, propagate to the others.
        if (MineTogetherChat.getTarget() == target) {
            MineTogetherChat.vanillaChat.m_93769_();
        }

        f_93761_.clear();
        m_93810_();

        synchronized (processedMessages) {
            for (InGameDisplayableMessage message : processedMessages) {
                message.format();
                message.display();
            }
        }
    }

    @Override
    public void m_93795_(boolean bl) {
        // If we are the target, propagate to the others.
        if (MineTogetherChat.getTarget() == target) {
            MineTogetherChat.vanillaChat.m_93795_(bl);
        }

        // Clear all messages. Do this manually as we don't use all the fields from ChatComponent.
        // This is more explicit on how we operate.
        synchronized (pendingMessages) {
            pendingMessages.clear();
        }
        synchronized (processedMessages) {
            for (InGameDisplayableMessage message : processedMessages) {
                message.onDead();
            }
            processedMessages.clear();
        }
        f_93761_.clear();
    }

    @Override
    public void m_93783_(String string) {
        if (channel == null) {
            LOGGER.error("Can't send message, chat is not bound!");
            return;
        }
        channel.sendMessage(string);
    }

    private void addMessage(Message message) {
        synchronized (processedMessages) {
            InGameDisplayableMessage newMessage = new InGameDisplayableMessage(message);
            processedMessages.add(newMessage);
            newMessage.display();

            if (m_93818_() && f_93763_ > 0) {
                f_93764_ = true;
                m_205360_(1);
            }

            while (processedMessages.size() > MAX_MESSAGE_HISTORY) {
                InGameDisplayableMessage toRemove = processedMessages.remove(0);
                f_93761_.removeAll(toRemove.getTrimmedLines());
                toRemove.onDead();
            }
        }
    }

    /**
     * Adds a message directly to the MT chat window bypassing IRC.
     * This is a client side only message.
     * <p>
     * Warning, This implementation is kinda hacky and may not be entirely reliable.
     *
     * Oh, and it seems this does not support text wrapping so... yay....
     *
     * @param message   The message. or null to remove a previous message.
     * @param signature The message signature, If a previous message exists with this signature it will be removed before the new message is added.
     */
    public void localMessage(@Nullable Component message, MessageSignature signature) {
        synchronized (processedMessages) {
            LocalMessage oldMessage = FastStream.of(processedMessages)
                    .filter(e -> e instanceof LocalMessage msg && msg.signature.equals(signature))
                    .map(e -> (LocalMessage) e)
                    .findFirst()
                    .orElse(null);

            if (oldMessage != null) {
                processedMessages.remove(oldMessage);
                if (oldMessage.line != null) {
                    f_93761_.remove(oldMessage.line);
                }
            }

            if (message == null) return;

            InGameDisplayableMessage newMessage = new LocalMessage(message, signature);
            processedMessages.add(newMessage);
            newMessage.display();

            if (m_93818_() && f_93763_ > 0) {
                f_93764_ = true;
                m_205360_(1);
            }

            while (processedMessages.size() > MAX_MESSAGE_HISTORY) {
                InGameDisplayableMessage toRemove = processedMessages.remove(0);
                f_93761_.removeAll(toRemove.getTrimmedLines());
                toRemove.onDead();
            }
        }
    }

    @Override
    public void m_93785_(Component component) {
        assert !internalUpdate; // We don't use this to add messages.

        MineTogetherChat.vanillaChat.m_93785_(component);
    }

    @Override
    public void m_240964_(Component component, @Nullable MessageSignature messageSignature, @Nullable GuiMessageTag guiMessageTag) {
        assert !internalUpdate; // We don't use this to add messages.

        MineTogetherChat.vanillaChat.m_240964_(component, messageSignature, guiMessageTag);
    }

    @Override
    public void m_240465_(Component component, @Nullable MessageSignature messageSignature, int i, @Nullable GuiMessageTag guiMessageTag, boolean bl) {
        assert !internalUpdate; // We don't use this to add messages.

        MineTogetherChat.vanillaChat.m_240465_(component, messageSignature, i, guiMessageTag, bl);
    }
    @Override
    public void m_240953_(MessageSignature messageSignature) {
        assert !internalUpdate; // We don't use this to add messages.

        MineTogetherChat.vanillaChat.m_240953_(messageSignature);
    }

    public boolean handleClick(double mouseX, double mouseY) {
        if (!m_93818_()) return false;

        double x = mouseX - 2.0;
        double y = (double) minecraft.m_91268_().m_85446_() - mouseY - 40.0;
        x = Mth.m_14107_(x / m_93815_());
        y = Mth.m_14107_(y / (m_93815_() * (minecraft.f_91066_.m_232101_().m_231551_() + 1.0)));
        if (x < 0.0 || y < 0.0) return false;

        int i = Math.min(m_93816_(), f_93761_.size());
        if (x <= (double) Mth.m_14107_((double) m_93813_() / m_93815_())) {
            Objects.requireNonNull(minecraft.f_91062_);
            if (y < (double) (9 * i + i)) {
                Objects.requireNonNull(minecraft.f_91062_);
                int j = (int) (y / 9.0 + (double) f_93763_);
                if (j >= 0 && j < f_93761_.size()) {
                    return handleClickedMessage(findMessageForTrimmedMessage(f_93761_.get(j)), x);
                }
            }
        }

        return false;
    }

    // TOOD unify with above and bellow.
    @Nullable
    public Style getStyleUnderMouse(double mouseX, double mouseY) {
        if (!m_93818_()) return null;

        double x = mouseX - 2.0;
        double y = (double) minecraft.m_91268_().m_85446_() - mouseY - 40.0;
        x = Mth.m_14107_(x / m_93815_());
        y = Mth.m_14107_(y / (m_93815_() * (minecraft.f_91066_.m_232101_().m_231551_() + 1.0)));
        if (x < 0.0 || y < 0.0) return null;

        int i = Math.min(m_93816_(), f_93761_.size());
        if (x <= (double) Mth.m_14107_((double) m_93813_() / m_93815_())) {
            Objects.requireNonNull(minecraft.f_91062_);
            if (y < (double) (9 * i + i)) {
                Objects.requireNonNull(minecraft.f_91062_);
                int j = (int) (y / 9.0 + (double) f_93763_);
                if (j >= 0 && j < f_93761_.size()) {
                    InGameDisplayableMessage message = findMessageForTrimmedMessage(f_93761_.get(j));
                    if (message == null) return null;
                    return minecraft.f_91062_.m_92865_().m_92386_(message.getBuiltMessage(), (int) x);
                }
            }
        }
        return null;
    }

    @Nullable
    public Message getMessageUnderMouse(double mouseX, double mouseY) {
        if (!m_93818_()) return null;

        double x = mouseX - 2.0;
        double y = (double) minecraft.m_91268_().m_85446_() - mouseY - 40.0;
        x = Mth.m_14107_(x / m_93815_());
        y = Mth.m_14107_(y / (m_93815_() * (minecraft.f_91066_.m_232101_().m_231551_() + 1.0)));
        if (x < 0.0 || y < 0.0) return null;

        int i = Math.min(m_93816_(), f_93761_.size());
        if (x <= (double) Mth.m_14107_((double) m_93813_() / m_93815_())) {
            Objects.requireNonNull(minecraft.f_91062_);
            if (y < (double) (9 * i + i)) {
                Objects.requireNonNull(minecraft.f_91062_);
                int j = (int) (y / 9.0 + (double) f_93763_);
                if (j >= 0 && j < f_93761_.size()) {
                    InGameDisplayableMessage message = findMessageForTrimmedMessage(f_93761_.get(j));
                    return message == null ? null : message.getMessage();
                }
            }
        }

        return null;
    }

    private boolean handleClickedMessage(@Nullable InGameDisplayableMessage clickedMessage, double x) {
        if (clickedMessage == null) return false;

        Message message = clickedMessage.getMessage();
        if (message.sender == null) return false;
        if (message.sender == MineTogetherChat.getOurProfile()) return false;

        Style style = minecraft.f_91062_.m_92865_().m_92386_(clickedMessage.getBuiltMessage(), (int) x);
        if (style == null) return false;
        ClickEvent event = style.m_131182_();
        if (event == null) return false;
        if (!event.m_130623_().equals(MessageFormatter.CLICK_NAME)) return false;

        this.clickedMessage = message;
        return true;
    }

    @Nullable
    private InGameDisplayableMessage findMessageForTrimmedMessage(GuiMessage.Line trimmedMessage) {
        // Little slow, realistically we should have a lookup map, but would be a pain to maintain.
        // This searches from the most recent chat message to the oldest.
        synchronized (processedMessages) {
            for (InGameDisplayableMessage processedMessage : processedMessages) {
                if (processedMessage.getTrimmedLines().contains(trimmedMessage)) {
                    return processedMessage;
                }
            }
        }
        return null;
    }

    @Nullable
    public Message getClickedMessage() {
        return clickedMessage;
    }

    public void clearClickedMessage() {
        clickedMessage = null;
    }

    private class InGameDisplayableMessage extends DisplayableMessage<GuiMessage.Line> {

        private InGameDisplayableMessage(Message message) {
            super(message);
        }

        @Override
        protected void onModified() {
            synchronized (changedMessages) {
                changedMessages.add(this);
            }
        }

        @Override
        protected boolean isForward() {
            return false;
        }

        @Override
        protected GuiMessage.Line createMessage(int addTime, FormattedCharSequence message) {
            return new GuiMessage.Line(addTime, message, null, true);// TODO true is not correct here, we need to pass it down.
        }

        @Override
        protected int getMessageIndex(GuiMessage.Line message) {
            return f_93761_.indexOf(message);
        }

        @Override
        protected void clearMessages() {
            f_93761_.removeAll(getTrimmedLines());
        }

        @Override
        protected void addMessage(int index, GuiMessage.Line message) {
            f_93761_.add(index, message);
        }

        @Override
        protected double getChatWidth() {
            return (double) m_93813_() / m_93815_();
        }
    }

    private class LocalMessage extends InGameDisplayableMessage {
        private final Component message;
        private final MessageSignature signature;
        @Nullable
        private GuiMessage.Line line;

        private LocalMessage(Component message, MessageSignature signature) {
            super(new Message(Instant.now(), MineTogetherChat.getOurProfile(), MessageComponent.of(), MessageComponent.of()));
            this.message = message;
            this.signature = signature;
        }

        @Override
        protected GuiMessage.Line createMessage(int addTime, FormattedCharSequence formattedCharSequence) {
            return line = new GuiMessage.Line(addTime, message.m_7532_(), null, true);
        }
    }
}

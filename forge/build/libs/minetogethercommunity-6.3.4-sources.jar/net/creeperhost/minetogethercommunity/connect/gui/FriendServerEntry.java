package net.creeperhost.minetogethercommunity.connect.gui;

import com.mojang.blaze3d.platform.NativeImage;
import net.creeperhost.minetogethercommunity.connect.RemoteServer;
import net.creeperhost.minetogether.lib.chat.profile.Profile;
import net.minecraft.ChatFormatting;
import net.minecraft.SharedConstants;
import net.minecraft.Util;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.FaviconTexture;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.ServerSelectionList;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.server.LanServer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * Created by brandon3055 on 21/04/2023
 */
public class FriendServerEntry extends ServerSelectionList.NetworkServerEntry {
    private static final ResourceLocation ICONS_LOCATION = new ResourceLocation("textures/gui/icons.png");
    private static final ResourceLocation SERVER_SELECTION_LOCATION = new ResourceLocation("textures/gui/server_selection.png");
    private static final Component INCOMPATIBLE_TOOLTIP = Component.m_237115_("multiplayer.status.incompatible");
    private static final Component NO_CONNECTION_TOOLTIP = Component.m_237115_("multiplayer.status.no_connection");
    private static final Component PINGING_TOOLTIP = Component.m_237115_("multiplayer.status.pinging");

    private final JoinMultiplayerScreen screen;
    private final FaviconTexture icon;
    public final RemoteServer remoteServer;
    public final Profile friendProfile;
    private final ServerListAppender listAppender;
    @Nullable
    private byte[] lastIconBytes;

    protected FriendServerEntry(JoinMultiplayerScreen joinMultiplayerScreen, RemoteServer remoteServer, Profile friendProfile, ServerListAppender listAppender) {
        super(joinMultiplayerScreen, new LanServer("Dummy Server", "0.0.0.0"));
        this.screen = joinMultiplayerScreen;
        this.remoteServer = remoteServer;
        this.friendProfile = friendProfile;
        this.listAppender = listAppender;
        this.icon = FaviconTexture.m_289187_(this.f_99828_.m_91097_(), friendProfile.getFullHash().toLowerCase(Locale.ROOT));
    }

    @Override                                                 //Yes. y, then x. This is correct. wtf...
    public void m_6311_(GuiGraphics graphics, int entryIndex, int y, int x, int entryWidth, int m, int mouseX, int mouseY, boolean selected, float f) {
        //Do Ping
        if (!remoteServer.pinged) {
            remoteServer.pinged = true;
            remoteServer.ping = -2L;
            remoteServer.motd = Component.m_237119_();
            remoteServer.status = Component.m_237119_();
            ServerSelectionList.f_99757_.submit(() -> {
                try {
                    listAppender.pingServer(remoteServer, friendProfile);
                } catch (Exception var2) {
                    remoteServer.ping = -1L;
                }
            });
        }

        //Draw Server Title
        graphics.m_280430_(this.f_99828_.f_91062_, Component.m_237110_("minetogether.connect.friend.server.title", getDisplayName()), x + 32 + 3, y + 1, 16777215);

        //Draw MOTD
        List<FormattedCharSequence> list = this.f_99828_.f_91062_.m_92923_(this.remoteServer.motd, entryWidth - 32 - 2);
        for (int line = 0; line < Math.min(list.size(), 2); ++line) {
            Font var10000 = this.f_99828_.f_91062_;
            FormattedCharSequence var10002 = list.get(line);
            int var10003 = (x + 32 + 3);
            int var10004 = y + 12;
            Objects.requireNonNull(this.f_99828_.f_91062_);
            graphics.m_280648_(var10000, var10002, var10003, (var10004 + 9 * line), 8421504);
        }

        boolean versionMismatch = this.remoteServer.protocol != SharedConstants.m_183709_().m_132495_();
        //Num Players or Version Mismatch text
        Component statusText = versionMismatch ? this.remoteServer.version.m_6881_().m_130940_(ChatFormatting.RED) : this.remoteServer.status;
        //Draw Status
        int statusWidth = this.f_99828_.f_91062_.m_92852_(statusText);
        graphics.m_280430_(this.f_99828_.f_91062_, statusText, (x + entryWidth - statusWidth - 15 - 2), (y + 1), 8421504);

        int statusIcon = 0;
        boolean scanning = false;
        List<Component> playersToolTip;
        Component statusToolTip;
        if (versionMismatch) {
            statusIcon = 5;
            statusToolTip = INCOMPATIBLE_TOOLTIP;
            playersToolTip = this.remoteServer.playerList;
        } else if (this.remoteServer.pinged && this.remoteServer.ping != -2L) {
            if (this.remoteServer.ping < 150L) {
                statusIcon = 0;
            } else if (this.remoteServer.ping < 300L) {
                statusIcon = 1;
            } else if (this.remoteServer.ping < 600L) {
                statusIcon = 2;
            } else if (this.remoteServer.ping < 1000L) {
                statusIcon = 3;
            } else {
                statusIcon = 4;
            }

            if (this.remoteServer.ping < 0L) {
                statusToolTip = NO_CONNECTION_TOOLTIP;
                statusIcon = 5;
                playersToolTip = Collections.emptyList();
            } else {
                statusToolTip = Component.m_237110_("multiplayer.status.ping", this.remoteServer.ping);
                playersToolTip = this.remoteServer.playerList;
            }
        } else {
            scanning = true;
            statusIcon = (int) (Util.m_137550_() / 100L + (long) (entryIndex * 2) & 7L);
            if (statusIcon > 4) statusIcon = 8 - statusIcon;

            statusToolTip = PINGING_TOOLTIP;
            playersToolTip = Collections.emptyList();
        }

        //Draw Signal / Scanning Bars.
        graphics.m_280163_(ICONS_LOCATION, x + entryWidth - 15, y, scanning ? 10.0F : 0.0F, 176.0F + statusIcon * 8.0F, 10, 8, 256, 256);

        //Update server icon.
        byte[] bs = this.remoteServer.getIconBytes();
        if (!Arrays.equals(bs, this.lastIconBytes)) {
            if (this.uploadServerIcon(bs)) {
                this.lastIconBytes = bs;
            } else {
                this.remoteServer.setIconBytes(null);
            }
        }

        this.drawIcon(graphics, x, y, this.icon.m_289196_());

        int t = mouseX - x;
        int u = mouseY - y;
        if (t >= entryWidth - 15 && t <= entryWidth - 5 && u >= 0 && u <= 8) {
            //Draw Status Tool Tip
            this.screen.m_257959_(Collections.singletonList(statusToolTip.m_7532_()));
        } else if (t >= entryWidth - statusWidth - 15 - 2 && t <= entryWidth - 15 - 2 && u >= 0 && u <= 8) {
            //Draw Players Tool Tip
            if (playersToolTip != null) {
                this.screen.m_257959_(playersToolTip.stream().map(Component::m_7532_).toList());
            }
        }

        if (this.f_99828_.f_91066_.m_231828_().m_231551_() || selected) {
            graphics.m_280509_(x, y, x + 32, y + 32, 0xa0909090);
            int v = mouseX - x;
            //Draw "Join Arrow"
            if (v < 32 && v > 16) {
                graphics.m_280163_(SERVER_SELECTION_LOCATION, x, y, 0.0F, 32.0F, 32, 32, 256, 256);
            } else {
                graphics.m_280163_(SERVER_SELECTION_LOCATION, x, y, 0.0F, 0.0F, 32, 32, 256, 256);
            }
        }
    }

    public String getDisplayName() {
        return friendProfile.isFriend() ? friendProfile.getFriendName() : friendProfile.getDisplayName();
    }

    protected void drawIcon(GuiGraphics graphics, int i, int j, ResourceLocation resourceLocation) {
        graphics.m_280163_(resourceLocation, i, j, 0.0F, 0.0F, 32, 32, 32, 32);
    }

    private boolean uploadServerIcon(@Nullable byte[] bs) {
        if (bs == null) {
            this.icon.m_289218_();
        } else {
            try {
                this.icon.m_289201_(NativeImage.m_271751_(bs));
            } catch (Throwable var3) {
                return false;
            }
        }

        return true;
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        if (listAppender.getServerList() != null) {
            double f = mouseX - listAppender.getServerList().m_5747_();
            if (f < 32.0 && f > 16.0) {
                this.screen.m_99700_(this);
                this.screen.m_99729_();
                return true;
            }
        }

        return super.m_6375_(mouseX, mouseY, button);
    }
}

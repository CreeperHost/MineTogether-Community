package net.creeperhost.minetogethercommunity.connect.gui;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import net.creeperhost.minetogethercommunity.MineTogetherClient;
import net.creeperhost.minetogethercommunity.chat.gui.MTStyle;
import net.creeperhost.minetogethercommunity.connect.ConnectHandler;
import net.creeperhost.minetogethercommunity.connect.netty.NettyClient;
import net.creeperhost.minetogethercommunity.gui.LoadingSpinner;
import net.creeperhost.minetogethercommunity.gui.MTTextures;
import net.creeperhost.minetogether.session.JWebToken;
import net.creeperhost.minetogether.session.MineTogetherSession;
import net.creeperhost.minetogethercommunity.orderform.OrderGui;
import net.creeperhost.polylib.client.modulargui.ModularGui;
import net.creeperhost.polylib.client.modulargui.ModularGuiScreen;
import net.creeperhost.polylib.client.modulargui.elements.*;
import net.creeperhost.polylib.client.modulargui.lib.Constraints;
import net.creeperhost.polylib.client.modulargui.lib.GuiProvider;
import net.creeperhost.polylib.client.modulargui.lib.SliderState;
import net.creeperhost.polylib.client.modulargui.lib.geometry.Axis;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.GameType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static net.creeperhost.polylib.client.modulargui.lib.geometry.Constraint.*;
import static net.creeperhost.polylib.client.modulargui.lib.geometry.GeoParam.*;
import static net.minecraft.ChatFormatting.*;

public class GuiShareToFriends implements GuiProvider {
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(1, new ThreadFactoryBuilder().setNameFormat("MT Connect Requests Thread %d").setDaemon(true).build());
    private static final Logger LOGGER = LogManager.getLogger();
    private GameType gameMode = GameType.SURVIVAL;
    private boolean commands = false;
    private int maxPlayers = 2;
    private double extraPlayers = maxPlayers - 1;
    private final SliderState playersState = SliderState.forSlider(() -> extraPlayers / (maxPlayers - 1), pos -> extraPlayers = (pos * (maxPlayers - 1)), () -> -1D / (maxPlayers - 1));

    private CompletableFuture<?> getPlayersTask = null;
    private boolean playerCheckError = false;
    private boolean noPlayerLimit = false;

    @Override
    public GuiElement<?> createRootElement(ModularGui gui) {
        return new GuiRectangle(gui).fill(0xC0000000);
    }

    @Override
    public void buildGui(ModularGui gui) {
        IntegratedServer integratedServer = gui.mc().m_91092_();
        gameMode = integratedServer.m_130008_();
        commands = integratedServer.m_129910_().m_5468_();

        gui.initFullscreenGui();
        GuiElement<?> root = gui.getRoot();

        GuiRectangle bounds = new GuiRectangle(root);//.border(0xFFFF0000);
        Constraints.size(bounds, 340, 226);
        Constraints.center(bounds, root);

        GuiTexture mineTogetherLogo = new GuiTexture(root, MTTextures.get("minetogether_connect"));
        Constraints.size(mineTogetherLogo, 256, 64);
        Constraints.placeInside(mineTogetherLogo, bounds, Constraints.LayoutPos.TOP_CENTER, 0, -15);

        GuiText shareInfo = new GuiText(root, Component.m_237115_("minetogether.connect.open.connect_intro").m_130940_(BLUE))
                .constrain(WIDTH, match(bounds.get(WIDTH)))
                .setWrap(true)
                .autoHeight();
        Constraints.placeOutside(shareInfo, mineTogetherLogo, Constraints.LayoutPos.BOTTOM_CENTER, 0, -8);

        GuiText connectInfo = new GuiText(root, Component.m_237115_("minetogether.connect.open.connect_security").m_130940_(GRAY))
                .constrain(WIDTH, match(bounds.get(WIDTH)))
                .setWrap(true)
                .autoHeight();
        Constraints.placeOutside(connectInfo, shareInfo, Constraints.LayoutPos.BOTTOM_CENTER, 0, 5);

        GuiText settingsInfo = new GuiText(root, Component.m_237115_("minetogether.connect.open.settings"))
                .constrain(WIDTH, match(root.get(WIDTH)))
                .constrain(HEIGHT, literal(9));
        Constraints.placeOutside(settingsInfo, connectInfo, Constraints.LayoutPos.BOTTOM_CENTER, 0, 5);

        GuiButton gameModeButton = MTStyle.Flat.button(root, Component.m_237119_())
                .onPress(() -> gameMode = GameType.values()[(gameMode.ordinal() + 1) % GameType.values().length])
                .constrain(TOP, relative(settingsInfo.get(BOTTOM), 5))
                .constrain(LEFT, match(bounds.get(LEFT)))
                .constrain(RIGHT, midPoint(bounds.get(LEFT), bounds.get(RIGHT), -5))
                .constrain(HEIGHT, literal(16));
        gameModeButton.getLabel().setTextSupplier(() -> Component.m_237115_("selectWorld.gameMode").m_130946_(": ").m_7220_(gameMode.m_151500_()));

        GuiButton cheatsButton = MTStyle.Flat.button(root, Component.m_237119_())
                .onPress(() -> commands = !commands)
                .constrain(TOP, relative(settingsInfo.get(BOTTOM), 5))
                .constrain(RIGHT, match(bounds.get(RIGHT)))
                .constrain(LEFT, midPoint(bounds.get(LEFT), bounds.get(RIGHT), 5))
                .constrain(HEIGHT, literal(16));
        cheatsButton.getLabel().setTextSupplier(() -> Component.m_237115_("selectWorld.allowCommands").m_130946_(": ").m_7220_(commands ? CommonComponents.f_130653_ : CommonComponents.f_130654_));

        //Players
        GuiRectangle sliderBg = new GuiRectangle(root)
                .setEnabled(() -> getPlayersTask == null)
                .border(0xFF909090)
                .constrain(LEFT, match(gameModeButton.get(LEFT)))
                .constrain(RIGHT, match(cheatsButton.get(RIGHT)))
                .constrain(TOP, relative(gameModeButton.get(BOTTOM), 5))
                .constrain(HEIGHT, literal(16));

        GuiSlider slider = new GuiSlider(sliderBg, Axis.X)
//                .setTooltip(Component.translatable("minetogether.connect.open.max_players.info"))
                .setSliderState(playersState);
//        slider.setEnableToolTip(() -> !slider.isDragging());
        Constraints.bind(slider, sliderBg, 1);

        sliderBg.fill(() -> slider.isMouseOver() || slider.isDragging() ? 0xFF202020 : 0xFF000000);

        GuiRectangle handle = new GuiRectangle(slider)
                .border(0xFF00FF00)
                .fill(0xFF007700)
                .constrain(WIDTH, literal(14));
        GuiRectangle handle2 = new GuiRectangle(handle)
                .border(0xFF00FF00)
                .fill(0xFF007700)
                .constrain(WIDTH, literal(6))
                .constrain(HEIGHT, match(handle.get(HEIGHT)));
        Constraints.center(handle2, handle);

        slider.installSlider(handle)
                .bindSliderWidth();

        GuiText maxPlayersText = new GuiText(sliderBg)
                .constrain(WIDTH, relative(sliderBg.get(WIDTH), -10))
                .constrain(HEIGHT, literal(16))
                .setTextSupplier(() -> Component.m_237115_("minetogether.connect.open.max_players").m_130946_(": ").m_7220_(playersDisplay(getPlayersSetting())));
        Constraints.center(maxPlayersText, sliderBg);

        //Loading Spinner / error info
        LoadingSpinner spinner = new LoadingSpinner(root)
                .setEnabled(() -> getPlayersTask != null);
        Constraints.size(spinner, 64, 64);
        Constraints.placeOutside(spinner, settingsInfo, Constraints.LayoutPos.BOTTOM_CENTER, 0, 35);

        GuiText getPlayersError = new GuiText(root, Component.m_237115_("minetogether.connect.open.max_players_error").m_130940_(ChatFormatting.RED))
                .setEnabled(() -> playerCheckError)
                .setWrap(true)
                .constrain(WIDTH, match(bounds.get(WIDTH)))
                .autoHeight();
        Constraints.placeOutside(getPlayersError, sliderBg, Constraints.LayoutPos.BOTTOM_CENTER, 0, 5);

        //Supporter Info
        GuiText supporterInfo = new GuiText(sliderBg)
                .setEnabled(() -> !playerCheckError && !noPlayerLimit)
                .setWrap(true)
                .constrain(WIDTH, match(bounds.get(WIDTH)))
                .autoHeight();
        supporterInfo.setTextSupplier(() -> Component.m_237115_("minetogether.connect.open.mt_supporter_info").m_130940_(supporterInfo.isMouseOver() ? UNDERLINE : GRAY).m_130940_(supporterInfo.isMouseOver() ? BLUE : GRAY));
        Constraints.placeOutside(supporterInfo, sliderBg, Constraints.LayoutPos.BOTTOM_CENTER, 0, 5);

        GuiButton supporterLink = new GuiButton(sliderBg)
                .setEnabled(supporterInfo::isEnabled)
                .onClick(() -> openLink(gui, "https://minetogether.io/profile/subscriptions"));
        Constraints.bind(supporterLink, supporterInfo);

        //Order page link
        GuiText orderInfo = new GuiText(sliderBg)
                .setWrap(true)
                .constrain(WIDTH, match(bounds.get(WIDTH)))
                .autoHeight();
        orderInfo.setTextSupplier(() -> Component.m_237115_("minetogether.connect.open.order_info").m_130940_(orderInfo.isMouseOver() ? UNDERLINE : GRAY).m_130940_(orderInfo.isMouseOver() ? BLUE : GRAY));
        Constraints.placeOutside(orderInfo, supporterInfo, Constraints.LayoutPos.BOTTOM_CENTER, 0, 5);

        GuiButton orderLink = new GuiButton(sliderBg)
                .setEnabled(orderInfo::isEnabled)
                .onClick(() -> handleOrderLink(gui));
        Constraints.bind(orderLink, orderInfo);

        //Go / Cancel
        GuiButton openButton = MTStyle.Flat.buttonPrimary(root, Component.m_237115_("minetogether.connect.open.start"))
                .onPress(() -> openWorld(gui))
                .constrain(BOTTOM, match(bounds.get(BOTTOM)))
                .constrain(LEFT, match(bounds.get(LEFT)))
                .constrain(RIGHT, midPoint(bounds.get(LEFT), bounds.get(RIGHT), -5))
                .constrain(HEIGHT, literal(16));

        GuiButton cancelButton = MTStyle.Flat.button(root, Component.m_237115_("gui.cancel"))
                .onPress(() -> gui.getScreen().m_7379_())
                .constrain(BOTTOM, match(bounds.get(BOTTOM)))
                .constrain(RIGHT, match(bounds.get(RIGHT)))
                .constrain(LEFT, midPoint(bounds.get(LEFT), bounds.get(RIGHT), 5))
                .constrain(HEIGHT, literal(16));

        startPlayersCheck();
        gui.onTick(() -> {
            if (getPlayersTask != null && getPlayersTask.isDone()) {
                getPlayersTask = null;
            }
        });
    }

    private void handleOrderLink(ModularGui gui) {
        //TODO, MT Partners Integration to open order GUI
        //If MT Partners is installed use that screen, If not use ours
//        gui.mc().setScreen(new OrderGui.Screen(gui.getScreen(), true));
//        openLink(gui, "https://www.creeperhost.net/mcm/order");
        MineTogetherClient.openOrderUI(gui);
    }

    private int getPlayersSetting() {
        int value = 1 + Math.max(0, Math.min((int) Math.round(extraPlayers), maxPlayers));
        return value >= 100 ? Integer.MAX_VALUE : value;
    }

    private Component playersDisplay(int players) {
        return Component.m_237113_(players == Integer.MAX_VALUE ? "\u221E" : String.valueOf(players));
    }

    private void openWorld(ModularGui gui) {
        gui.mc().m_91152_(null);
        gui.mc().f_91065_.m_93076_().m_93785_(Component.m_237115_("minetogether.connect.open.attempting"));
        ConnectHandler.publishToFriends(gameMode, commands, getPlayersSetting());
    }

    private void startPlayersCheck() {
        getPlayersTask = CompletableFuture.runAsync(() -> {
            try {
                JWebToken token = MineTogetherSession.getDefault().getTokenAsync().get();
                maxPlayers = NettyClient.getMaxPlayers(ConnectHandler.getEndpoint(), token);
                if (maxPlayers == -1) {
                    noPlayerLimit = true;
                    maxPlayers = 100;
                }
                extraPlayers = maxPlayers - 1;
                playerCheckError = false;
            } catch (Throwable e) {
                playerCheckError = true;
                maxPlayers = 2;
                extraPlayers = 1;
                LOGGER.error("An error occurred while attempting to check max players", e);
            }
        }, EXECUTOR);
    }

    private void openLink(ModularGui gui, String url) {
        gui.mc().m_91152_(new ConfirmLinkScreen((bl) -> {
            if (bl) {
                Util.m_137581_().m_137646_(url);
            }

            gui.mc().m_91152_(gui.getScreen());
        }, url, true));
    }

    public static class Screen extends ModularGuiScreen {
        public Screen(net.minecraft.client.gui.screens.Screen parentScreen) {
            super(new GuiShareToFriends(), parentScreen);
            modularGui.setPauseScreen(true);
        }
    }
}

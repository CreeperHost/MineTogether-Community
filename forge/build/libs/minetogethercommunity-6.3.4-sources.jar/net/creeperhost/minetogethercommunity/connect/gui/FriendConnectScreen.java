package net.creeperhost.minetogethercommunity.connect.gui;

import com.mojang.logging.LogUtils;
import net.creeperhost.minetogethercommunity.connect.ConnectHandler;
import net.creeperhost.minetogethercommunity.connect.ConnectHost;
import net.creeperhost.minetogethercommunity.connect.RemoteServer;
import net.creeperhost.minetogethercommunity.connect.netty.NettyClient;
import net.creeperhost.minetogether.session.JWebToken;
import net.creeperhost.minetogether.session.MineTogetherSession;
import net.minecraft.DefaultUncaughtExceptionHandler;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientHandshakePacketListenerImpl;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.chat.report.ReportEnvironment;
import net.minecraft.client.quickplay.QuickPlayLog;
import net.minecraft.client.server.LanServer;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.protocol.handshake.ClientIntentionPacket;
import net.minecraft.network.protocol.login.ServerboundHelloPacket;
import org.slf4j.Logger;

import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;


public class FriendConnectScreen extends ConnectScreen {
    private static final AtomicInteger UNIQUE_THREAD_ID = new AtomicInteger(0);
    private static final Logger LOGGER = LogUtils.getLogger();
    private volatile boolean aborted;
    private final Screen parent;
    private Component status = Component.m_237115_("connect.connecting");
    private long lastNarration = -1L;

    private FriendConnectScreen(Screen screen) {
        super(screen, CommonComponents.f_130661_);
        parent = screen;
    }

    public static void startConnecting(Screen screen, Minecraft minecraft, RemoteServer server, LanServer serverData) {
        FriendConnectScreen connectScreen = new FriendConnectScreen(screen);
        minecraft.m_91399_();
        minecraft.m_193588_();
        minecraft.m_239476_(ReportEnvironment.m_238998_(serverData.m_120079_()));
        minecraft.m_278644_().m_278642_(QuickPlayLog.Type.MULTIPLAYER, serverData.m_120079_(), "MT Friend Server"); //< TODO Ideally we want the world or the friend name here
        minecraft.m_91152_(connectScreen);
        connectScreen.connect(minecraft, server);
    }

    private void connect(Minecraft minecraft, RemoteServer server) {
        LOGGER.info("Connecting to friend server, {}", server.friend);
        Thread thread = new Thread("MT Server Connector #" + UNIQUE_THREAD_ID.incrementAndGet()) {
            public void run() {
                try {
                    if (aborted) return;

                    synchronized (FriendConnectScreen.this) {
                        ConnectHost endpoint = ConnectHandler.getSpecificEndpoint(server.node);
                        JWebToken token = MineTogetherSession.getDefault().getTokenAsync().get();
                        f_95684_ = NettyClient.connect(endpoint, token, server.serverToken, false);
                        f_95684_.m_129505_(new ClientHandshakePacketListenerImpl(f_95684_, minecraft, new ServerData("", "", false), parent, false, (Duration) null, FriendConnectScreen.this::m_95717_));
                        f_95684_.m_129512_(new ClientIntentionPacket(endpoint.address(), endpoint.proxyPort(), ConnectionProtocol.LOGIN));
                        f_95684_.m_129512_(new ServerboundHelloPacket(minecraft.m_91094_().m_92546_(), Optional.of(minecraft.m_91094_().m_240411_())));
                    }
                } catch (Exception ex) {
                    if (aborted) {
                        return;
                    }
                    FriendConnectScreen.LOGGER.error("Couldn't connect to server", ex);

                    Exception loggedException = ex.getCause() instanceof Exception e ? e : ex;


                    String string = loggedException.getMessage();
                    minecraft.execute(() -> {
                        minecraft.m_91152_(new DisconnectedScreen(parent, CommonComponents.f_130661_, Component.m_237110_("disconnect.genericReason", string)));
                    });
                }

            }
        };
        thread.setUncaughtExceptionHandler(new DefaultUncaughtExceptionHandler(LOGGER));
        thread.start();
    }

    private void m_95717_(Component component) {
        status = component;
    }

    public void m_86600_() {
        if (f_95684_ != null) {
            if (f_95684_.m_129536_()) {
                f_95684_.m_129483_();
            } else {
                f_95684_.m_129541_();
            }
        }

    }

    public boolean m_6913_() {
        return false;
    }

    protected void m_7856_() {
        m_142416_(Button.m_253074_(CommonComponents.f_130656_, (button) -> {
                            aborted = true;
                            if (f_95684_ != null) {
                                f_95684_.m_129507_(Component.m_237115_("connect.aborted"));
                            }

                            f_96541_.m_91152_(parent);
                        })
                        .m_252987_(f_96543_ / 2 - 100, f_96544_ / 4 + 120 + 12, 200, 20)
                        .m_253136_()
        );
    }

    public void m_88315_(GuiGraphics graphics, int i, int j, float f) {
        m_280273_(graphics);
        long l = Util.m_137550_();
        if (l - lastNarration > 2000L) {
            lastNarration = l;
            f_96541_.m_240477_().m_168785_(Component.m_237115_("narrator.joining"));
        }

        graphics.m_280653_(f_96547_, status, f_96543_ / 2, f_96544_ / 2 - 50, 16777215);

        for (Renderable renderable : this.f_169369_) {
            renderable.m_88315_(graphics, i, j, f);
        }
    }
}

package net.creeperhost.minetogethercommunity.connect;

import dev.architectury.event.events.client.ClientGuiEvent;
import dev.architectury.hooks.client.screen.ScreenAccess;
import dev.architectury.hooks.client.screen.ScreenHooks;
import net.creeperhost.minetogethercommunity.config.Config;
import net.creeperhost.minetogethercommunity.connect.gui.ConnectPackSelectionScreen;
import net.creeperhost.minetogethercommunity.connect.gui.GuiShareToFriends;
import net.creeperhost.polylib.client.screen.ButtonHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;

import java.util.List;

public class MineTogetherConnect {

    public static boolean isInitted = false;

    public static void init() {
        isInitted = true;
        ConnectHandler.init();

        ClientGuiEvent.INIT_POST.register(MineTogetherConnect::onScreenOpen);
    }

    private static void onScreenOpen(Screen screen, ScreenAccess screenAccess) {
        if (screen instanceof TitleScreen) {
            ConnectPackSelectionScreen.promptIfNeeded(screen);
            return;
        }

        if (!(screen instanceof PauseScreen)) return;

        IntegratedServer integratedServer = Minecraft.m_91087_().m_91092_();
        if (integratedServer == null) return;

        boolean isConnectPublished = ConnectHandler.isPublished();
        Component buttonText = isConnectPublished ? Component.m_237115_("minetogether.connect.close") : Component.m_237115_("minetogether.connect.open");
        Button.OnPress action = button -> {
            if (isConnectPublished) {
                ConnectHandler.unPublish();
                Minecraft.m_91087_().m_91152_(new PauseScreen(true));
            } else {
                Minecraft.m_91087_().m_91152_(new GuiShareToFriends.Screen(screen));
            }
        };

        @SuppressWarnings ("unchecked")
        List<GuiEventListener> children = (List<GuiEventListener>) screen.m_6702_();
        List<Renderable> renderables = screenAccess.getRenderables();
        List<NarratableEntry> narratables = screenAccess.getNarratables();

        AbstractWidget feedBack = ButtonHelper.findButton("menu.sendFeedback", screen);
        AbstractWidget options = ButtonHelper.findButton("menu.options", screen);
        if (!Config.instance().moveButtonsOnPauseMenu || feedBack == null || options == null) {
            // Just add the button bellow the FriendsList button in the corner.
            // We either didn't find the Feedback and Options buttons, or moving these buttons was disabled in our config.
            Button openToFriends = Button.m_253074_(buttonText, action)
                    .m_252987_(screen.f_96543_ - 105, 25, 100, 20)
                    .m_253136_();
            ScreenHooks.addRenderableWidget(screen, openToFriends);
            return;
        }

        // Open To Friends button goes where the options button was.
        Button openToFriends = Button.m_253074_(buttonText, action)
                .m_252987_(options.m_252754_(), options.m_252907_(), 98, 20)
                .m_253136_();
        ScreenHooks.addRenderableWidget(screen, openToFriends);

        // Move the options button to where the feedback button was.
        options.m_253211_(feedBack.m_252907_());
        options.m_252865_(feedBack.m_252754_());

        // Again, we have to juggle indexes because of Mod Menu...
        children.remove(options);
        renderables.remove(options);
        narratables.remove(options);
        children.set(children.indexOf(feedBack), options);
        renderables.set(renderables.indexOf(feedBack), options);
        narratables.set(narratables.indexOf(feedBack), options);
    }
}

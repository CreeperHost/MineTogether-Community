package net.creeperhost.minetogethercommunity.connect;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.google.gson.Gson;
import net.covers1624.quack.collection.FastStream;
import net.covers1624.quack.gson.JsonUtils;
import net.creeperhost.minetogether.lib.web.requests.GetClosestDCRequest;
import net.creeperhost.minetogethercommunity.MineTogether;
import net.creeperhost.minetogethercommunity.chat.MineTogetherChat;
import net.creeperhost.minetogether.connect.lib.netty.packet.CFriendServers;
import net.creeperhost.minetogether.connect.lib.web.GetConnectServersRequest;
import net.creeperhost.minetogethercommunity.connect.netty.NettyClient;
import net.creeperhost.minetogether.lib.chat.profile.Profile;
import net.creeperhost.minetogether.lib.chat.profile.ProfileManager;
import net.creeperhost.minetogether.lib.web.ApiClientResponse;
import net.creeperhost.minetogether.session.JWebToken;
import net.creeperhost.minetogether.session.MineTogetherSession;
import net.creeperhost.minetogethercommunity.util.ModPackInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import org.apache.commons.lang3.NotImplementedException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by brandon3055 on 21/04/2023
 */
public class ConnectHandler {

    private static final Logger LOGGER = LogManager.getLogger();
    private static final Map<RemoteServer, Profile> AVAILABLE_SERVER_MAP = new HashMap<>();
    private static final ExecutorService SEARCH_EXECUTOR = Executors.newSingleThreadExecutor(new ThreadFactoryBuilder().setDaemon(true).setNameFormat("MT Connect Friend Search Executor").build());
    private static final ExecutorService SHARE_EXECUTOR = Executors.newSingleThreadExecutor(new ThreadFactoryBuilder().setDaemon(true).setNameFormat("MT Connect Friend Share Executor").build());

    private static long lastSearch = 0;
    private static CompletableFuture<?> activeSearch = null;
    private static List<CFriendServers.ServerEntry> searchResult = null;
    private static int defaultMaxPlayers = 8;

    // Useful for testing, can connect to specific node.
    private static final String FORCED_NODE = System.getProperty("connect.node");
    // Useful for testing, can force the use of a host list json. Running node mesh locally, for example.
    @Nullable
    private static final String NODE_HOSTS_OVERRIDE = System.getProperty("connect.mesh.hosts");
    private static final Gson GSON = new Gson();

    @Nullable
    private static ConnectHost endpoint;

    private static boolean didWeShareFirst = false;
    private static NettyClient.ProxyConnection publishedServer;

    public static void init() {
    }

    public static ConnectHost getEndpoint() {
        if (endpoint == null) {
            GetConnectServersRequest.ConnectServer node = chooseServer();
            LOGGER.info("Selected MTConnect server: " + node.name);

            endpoint = new ConnectHost(node);
        }
        return endpoint;
    }

    public static ConnectHost getSpecificEndpoint(@Nullable String node) throws IOException {
        if (node == null) {
            return getEndpoint();
        }

        List<GetConnectServersRequest.ConnectServer> servers = pollServers();
        if (servers == null || servers.isEmpty()) {
            throw new IllegalStateException("No server list returned.");
        }
        GetConnectServersRequest.ConnectServer server = FastStream.of(servers)
                .filter(e -> e.name.equals(node))
                .firstOrDefault();
        if (server == null) {
            throw new IllegalStateException("Did not find node with id: " + node);
        }
        return new ConnectHost(server);
    }

    private static GetConnectServersRequest.ConnectServer chooseServer() {
        if (Boolean.getBoolean("mt.develop.connect")) {
            return GetConnectServersRequest.ConnectServer.getLocalHost();
        }
        try {
            List<GetConnectServersRequest.ConnectServer> servers = pollServers();
            if (servers == null || servers.isEmpty()) {
                // TODO, this needs to gracefully fail as noted bellow.
                LOGGER.warn("No MTConnect nodes found.. :(");
                throw new NotImplementedException();
            }

            if (FORCED_NODE != null) {
                return FastStream.of(servers)
                        .filter(e -> e.name.equals(FORCED_NODE))
                        .first();
            }

            GetConnectServersRequest.ConnectServer first = servers.get(0);

            ApiClientResponse<GetClosestDCRequest.Response> closestDCResponse = MineTogether.API.execute(new GetClosestDCRequest());
            if (!closestDCResponse.hasBody()) {
                LOGGER.error("Failed to get Closest DC locations. Using first server: {}", first.name);
                return first;
            }

            for (GetClosestDCRequest.DataCenter dc : closestDCResponse.apiResponse().getDataCenters()) {
                for (GetConnectServersRequest.ConnectServer server : servers) {
                    if (server.location.equals(dc.getName())) {
                        LOGGER.info("Selected server {}. Closest DC was {}.", server.name, dc.getName());
                        return server;
                    }
                }
            }

            LOGGER.info("Could not select a server. Using first server: {}", first.name);
            return first;
        } catch (IOException ex) {
            // TODO, this needs to gracefully fail, getEndpoint likely needs to return null, and isEnabled needs to return false.
            throw new NotImplementedException("TODO, Implement exception handling for this:", ex);
        }
    }

    @Nullable
    private static List<GetConnectServersRequest.ConnectServer> pollServers() throws IOException {
        if (NODE_HOSTS_OVERRIDE != null) {
            return JsonUtils.parse(GSON, Path.of(NODE_HOSTS_OVERRIDE), GetConnectServersRequest.LIST_SERVERS);
        }
        ApiClientResponse<List<GetConnectServersRequest.ConnectServer>> apiResp = MineTogether.API.execute(new GetConnectServersRequest());
        if (apiResp.statusCode() != 200) {
            LOGGER.error("Failed to query node list. Got: {}", apiResp.statusCode());
            return null;
        }
        return apiResp.apiResponse();
    }

    public static boolean isEnabled() {
        return true; //TODO v2
    }

    public static void publishToFriends(GameType gameType, boolean cheats, int maxPlayers) {
        // Mostly copy of IntegratedServer#publishServer
        Minecraft mc = Minecraft.m_91087_();
        IntegratedServer server = mc.m_91092_();
        if (server == null) return;
        defaultMaxPlayers = server.m_6846_().f_11193_;
        server.m_6846_().f_11193_ = Math.min(2, maxPlayers); //Set to the minimum, here, later it may be increased as appropriate inside NettyClient.publishServer
        mc.m_193588_();

        if (server.m_6992_()) {
            didWeShareFirst = false;
        } else {
            didWeShareFirst = true;
            server.f_120017_ = 0; // Doesn't matter, just set to _something_.
        }
        server.f_174966_ = gameType;
        server.m_6846_().m_11284_(cheats);
        mc.f_91074_.m_108648_(server.m_129944_(mc.f_91074_.m_36316_()));

        for (ServerPlayer player : server.m_6846_().m_11314_()) {
            server.m_129892_().m_82095_(player);
        }

        CompletableFuture.runAsync(() -> {
            try { // TODO, This should be done outside somewhere.
                JWebToken token = MineTogetherSession.getDefault().getTokenAsync().get();
                publishedServer = NettyClient.publishServer(server, getEndpoint(), token, getModpackKey(), maxPlayers);
            } catch (Exception e) {
                Minecraft.m_91087_().f_91065_.m_93076_().m_93785_(Component.m_237110_("minetogether.connect.open.failed", e.getMessage()));
                LOGGER.error("Failed to open to friends", e);
                unPublish();
            }
        }, SHARE_EXECUTOR);
    }

    public static void unPublish() {
        Minecraft mc = Minecraft.m_91087_();
        IntegratedServer server = mc.m_91092_();
        if (server == null) return;
        // This will yeet the control socket, which, should cause the proxy to sever all other connections.
        if (publishedServer != null) {
            publishedServer.disconnect();
            publishedServer = null;
        }
        if (didWeShareFirst) {
            //Un-Share the world.
            server.f_120017_ = -1;
            server.f_174966_ = null;
        }
        server.m_6846_().f_11193_ = Math.max(defaultMaxPlayers, 8);
    }

    public static boolean isPublished() {
        return publishedServer != null;
    }

    public static void updateFriendsSearch() {
        if (activeSearch != null) {
            if (!activeSearch.isDone()) return;

            activeSearch = null;

            if (searchResult != null) {
                ProfileManager profileManager = MineTogetherChat.CHAT_STATE.profileManager;
                Set<RemoteServer> keep = new HashSet<>();
                for (CFriendServers.ServerEntry entry : searchResult) {
                    RemoteServer server = RemoteServer.fromEntry(entry);
                    ConnectPackResolver.prefetch(server.modpackKey);
                    keep.add(server);
                    if (!AVAILABLE_SERVER_MAP.containsKey(server)) {
                        Profile profile = profileManager.lookupProfile(entry.friend);
                        AVAILABLE_SERVER_MAP.put(server, profile);
                    }
                }

                AVAILABLE_SERVER_MAP.entrySet().removeIf(entry -> !keep.contains(entry.getKey()));
                searchResult = null;
            }
            return;
        }

        if (System.currentTimeMillis() - lastSearch < 5000) {
            return;
        }
        lastSearch = System.currentTimeMillis();

        activeSearch = CompletableFuture.runAsync(() -> {
            searchResult = null;
            try {
                JWebToken token = MineTogetherSession.getDefault().getTokenAsync().get();
                searchResult = NettyClient.getFriendServers(getEndpoint(), token, getModpackKey()).servers;
            } catch (Throwable e) {
                LOGGER.error("An error occurred while searching for friend servers.", e);
            }
        }, SEARCH_EXECUTOR);
    }

    public static Collection<RemoteServer> getRemoteServers() {
        return AVAILABLE_SERVER_MAP.keySet();
    }

    public static Profile getServerProfile(RemoteServer server) {
        return AVAILABLE_SERVER_MAP.get(server);
    }

    public static void clearAndReset() {
        if (activeSearch != null) {
            activeSearch.cancel(true);
            activeSearch = null;
            searchResult = null;
        }
        AVAILABLE_SERVER_MAP.clear();
        lastSearch = 0;
    }

    private static @Nullable String getModpackKey() {
        return ModPackInfo.getInfo().getConnectPackKey();
    }
}
